import discord
from discord import app_commands
from discord.ext import commands
import json
from datetime import datetime
import os

class RemoveScore(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    def load_json(self, filepath, default):
        """Load JSON data from a file, return default if file does not exist."""
        if not os.path.exists(filepath):
            print(f"File not found: {filepath}")
            return default
        try:
            with open(filepath, 'r') as f:
                return json.load(f)
        except json.JSONDecodeError:
            print(f"Error decoding JSON from file: {filepath}")
            return default

    def save_json(self, filepath, data):
        """Save JSON data to a file."""
        try:
            with open(filepath, 'w') as f:
                json.dump(data, f, indent=4)
        except Exception as e:
            print(f"Error saving JSON to file {filepath}: {e}")

    def is_mod(self, interaction: discord.Interaction, guild_id: str, user_id: str):
        """Check if a user is a mod based on the mod files."""
        mods_file = './json/mod.json'
        moduser_file = './json/moduser.json'

        # CWV - Load mod data
        mods_data = self.load_json(mods_file, {})
        moduser_data = self.load_json(moduser_file, {})

        # CWV - Debug logging
        print(f"Checking mod status for user {user_id} in guild {guild_id}")
        print(f"Mods data: {mods_data}")
        print(f"Moduser data: {moduser_data}")

        # CWV - Check if the user's roles include any mod roles
        guild_mod_roles = mods_data.get(str(guild_id), {}).get("roles", [])
        user_roles = [role.id for role in interaction.user.roles]
        is_mod_role = any(role_id in user_roles for role_id in guild_mod_roles)

        # CWV - Check if the user is in the moduser list for the guild
        guild_modusers = moduser_data.get(str(guild_id), {}).get("users", [])
        is_moduser = int(user_id) in guild_modusers

        is_mod = is_mod_role or is_moduser
        print(f"Is user a mod? {is_mod}")

        return is_mod

    @app_commands.command(name="removescore", description="Allows mods to remove any amount of points from a user.")
    @app_commands.describe(user="The user from whom points will be removed", points="The number of points to remove")
    async def removescore(self, interaction: discord.Interaction, user: discord.User, points: float):
        guild_id = str(interaction.guild.id)
        user_id = str(interaction.user.id)

        # CWV - Detailed logging for debugging
        print(f"removescore command invoked by {user_id} for user {user.id} in guild {guild_id}")

        try:
            if not self.is_mod(interaction, guild_id, user_id):
                await interaction.response.send_message("You don't have permission to use this command.", ephemeral=True)
                print(f"Permission denied for user {user_id}")
                return

            if points <= 0:
                await interaction.response.send_message("Please enter a positive number for points.", ephemeral=True)
                print(f"Invalid points value: {points}")
                return

            target_user_id = str(user.id)
            current_date = str(datetime.utcnow().date())

            # CWV - File path
            scores_file = './json/scores.json'

            # CWV - Load existing data with error handling
            try:
                scores_data = self.load_json(scores_file, {})
            except Exception as e:
                await interaction.response.send_message(f"Error loading data: {str(e)}", ephemeral=True)
                print(f"Error loading JSON data: {e}")
                return

            # CWV - Check if user data exists
            if guild_id not in scores_data or target_user_id not in scores_data[guild_id]:
                await interaction.response.send_message("User does not have any points to remove.", ephemeral=True)
                return

            user_scores = scores_data[guild_id][target_user_id]
            if user_scores["total"] < points:
                await interaction.response.send_message("You cannot remove more points than the user's total points.", ephemeral=True)
                return

            # CWV - Remove points from the most recent dates first
            remaining_points_to_remove = points
            dates_sorted = sorted(user_scores["dates"].items(), reverse=True)  # CWV - Sort dates in reverse (latest first)
            
            for date, date_points in dates_sorted:
                if remaining_points_to_remove <= 0:
                    break
                if date_points >= remaining_points_to_remove:
                    user_scores["dates"][date] -= remaining_points_to_remove
                    remaining_points_to_remove = 0
                else:
                    remaining_points_to_remove -= user_scores["dates"][date]
                    user_scores["dates"][date] = 0

            # CWV - Correct the total points after removal
            user_scores["total"] = sum(user_scores["dates"].values())

            # CWV - Save updated data to file
            try:
                self.save_json(scores_file, scores_data)
            except Exception as e:
                await interaction.response.send_message(f"Error saving data: {str(e)}", ephemeral=True)
                print(f"Error saving JSON data: {e}")
                return

            # CWV - Prepare the embed message
            embed = discord.Embed(
                title=f"Points removed from {user.name} in {interaction.guild.name}",
                description=(f"Removed **{points}** points from {user.mention}.\n"
                             f"Their new total points are **{user_scores['total']}**.\n"
                             f"Their total points today: **{user_scores['dates'].get(current_date, 0)}**."),
                color=discord.Color.red()
            )

            embed.set_author(name=interaction.user.name, icon_url=interaction.user.avatar.url if interaction.user.avatar else None)
            embed.set_footer(text="~ Made with ❤️ by CWV")

            await interaction.response.send_message(embed=embed)

        except Exception as e:
            error_message = f"An unexpected error occurred: {str(e)}"
            await interaction.response.send_message(error_message, ephemeral=True)
            print(f"Unexpected error in removescore command: {e}")

    @commands.Cog.listener()
    async def on_ready(self):
        print("RemoveScore cog is ready.")

async def setup(bot):
    await bot.add_cog(RemoveScore(bot))
