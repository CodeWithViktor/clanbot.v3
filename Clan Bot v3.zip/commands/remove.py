import discord
from discord import app_commands
from discord.ext import commands
import json
from datetime import datetime
import os

class RemovePoints(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    # CWV - Load or initialize JSON files
    def load_json(self, filepath, default):
        if not os.path.exists(filepath):
            return default
        with open(filepath, 'r') as f:
            return json.load(f)

    def save_json(self, filepath, data):
        with open(filepath, 'w') as f:
            json.dump(data, f, indent=4)

    @app_commands.command(name="remove", description="Remove your points")
    @app_commands.describe(points="The number of points to remove")
    async def remove(self, interaction: discord.Interaction, points: float):
        if points <= 0 or len(str(points).split(".")[1]) > 2:
            await interaction.response.send_message("Please enter a positive number with up to two decimal places.", ephemeral=True)
            return

        user_id = str(interaction.user.id)
        guild_id = str(interaction.guild.id)
        current_date = str(datetime.utcnow().date())

        scores_file = './json/scores.json'
        wins_file = './json/wins.json'

        # CWV - Load scores and wins data
        scores_data = self.load_json(scores_file, {})
        wins_data = self.load_json(wins_file, {})

        # CWV - Check if user data exists
        if guild_id not in scores_data or user_id not in scores_data[guild_id]:
            await interaction.response.send_message("You don't have any score to remove.", ephemeral=True)
            return

        user_scores = scores_data[guild_id][user_id]
        if user_scores["total"] < points:
            await interaction.response.send_message("You cannot remove more points than your total score.", ephemeral=True)
            return

        # CWV - Remove points from the most recent dates first
        remaining_points_to_remove = points
        dates_sorted = sorted(user_scores["dates"].items(), reverse=True)  # CWV - Sort dates in reverse (latest first)
        
        for date, date_points in dates_sorted:
            if remaining_points_to_remove <= 0:
                break
            if date_points >= remaining_points_to_remove:
                user_scores["dates"][date] -= remaining_points_to_remove
                remaining_points_to_remove = 0
            else:
                remaining_points_to_remove -= user_scores["dates"][date]
                user_scores["dates"][date] = 0

        # CWV - Correct the total score after removal
        user_scores["total"] = sum(user_scores["dates"].values())

        # CWV - Update wins
        if guild_id not in wins_data or user_id not in wins_data[guild_id]:
            await interaction.response.send_message("You don't have any wins to remove.", ephemeral=True)
            return

        user_wins = wins_data[guild_id][user_id]
        if user_wins["total"] > 0:
            user_wins["total"] -= 1
            if current_date in user_wins["dates"]:
                user_wins["dates"][current_date] -= 1

            # CWV - Ensure total wins is not less than the sum of date-wise wins
            total_date_wins = sum(user_wins["dates"].values())
            if user_wins["total"] < total_date_wins:
                user_wins["total"] = total_date_wins

        # CWV - Save updated data to files
        self.save_json(scores_file, scores_data)
        self.save_json(wins_file, wins_data)

        # CWV - Prepare an embed message
        embed = discord.Embed(
            title=f"Points removed in {interaction.guild.name}",
            description=f"Removed **{points}** points from your score.\nYour new score is **{user_scores['total']}** points.\nYour total Battle Wins are **{user_wins['total']}** wins.",
            color=discord.Color.red()
        )

        # CWV - Set the author with the user's avatar and username
        embed.set_author(name=interaction.user.name, icon_url=interaction.user.avatar.url)

        # CWV - Footer
        embed.set_footer(text="~ Made with ❤️ by CWV")

        # CWV - Respond to the user
        await interaction.response.send_message(embed=embed)

    @commands.Cog.listener()
    async def on_ready(self):
        print("RemovePoints cog is ready.")

async def setup(bot):
    await bot.add_cog(RemovePoints(bot))
