import discord
from discord import app_commands
from discord.ext import commands
import json

class ModInfo(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    def load_json(self, filepath, default):
        try:
            with open(filepath, 'r') as f:
                return json.load(f)
        except FileNotFoundError:
            return default

    @app_commands.command(name="mod-info", description="Get detailed information about mod roles and users")
    async def mod_info(self, interaction: discord.Interaction):
        mod_role_file = './json/mod.json'
        mod_user_file = './json/moduser.json'

        mod_role_data = self.load_json(mod_role_file, {})
        mod_user_data = self.load_json(mod_user_file, {})

        guild_id = str(interaction.guild.id)
        mod_roles = mod_role_data.get(guild_id, {}).get("roles", [])
        mod_users = mod_user_data.get(guild_id, {}).get("users", [])

        embed = discord.Embed(
            title="Server Mod Information",
            description=f"Detailed mod information for {interaction.guild.name}",
            color=discord.Color.blue()
        )

        # CWV - Add mod roles information
        if mod_roles:
            role_info = "\n".join(f"- <@&{role_id}>" for role_id in mod_roles)
        else:
            role_info = "No mod roles set."

        embed.add_field(
            name="Mod Roles",
            value=role_info,
            inline=False
        )

        # CWV - Add mod users information
        if mod_users:
            user_info = []
            for user_id in mod_users:
                user = interaction.guild.get_member(int(user_id))
                if user:
                    user_info.append(f"- {user.mention} (ID: {user_id})")
                else:
                    user_info.append(f"- <@{user_id}> (ID: {user_id}) - User not in server")
        else:
            user_info = ["No mod users set."]

        embed.add_field(
            name="Mod Users",
            value="\n".join(user_info),
            inline=False
        )

        # CWV - Adding details about who appointed the mod users
        for user_id in mod_users:
            user = interaction.guild.get_member(int(user_id))
            if user:
                appointing_user = next(
                    (appointer for appointer, details in mod_user_data.get(guild_id, {}).get("appointing_users", {}).items() if details.get("user_id") == user_id),
                    None
                )
                if appointing_user:
                    embed.add_field(
                        name=f"Appointer Info for {user.mention}",
                        value=f"Appointed by: <@{appointing_user}>",
                        inline=False
                    )
        
        await interaction.response.send_message(embed=embed)

async def setup(bot):
    await bot.add_cog(ModInfo(bot))
