import discord
from discord import app_commands
from discord.ext import commands
import json
from datetime import datetime

class SetModRole(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    def load_json(self, filepath, default):
        """Load JSON data from a file, return default if file does not exist."""
        try:
            with open(filepath, 'r') as f:
                return json.load(f)
        except FileNotFoundError:
            return default

    def save_json(self, filepath, data):
        """Save JSON data to a file."""
        with open(filepath, 'w') as f:
            json.dump(data, f, indent=4)

    def log_event(self, guild_id, user_id, action, details):
        """Log events to a file."""
        log_file = './json/event_logs.json'
        log_data = self.load_json(log_file, [])

        log_entry = {
            "timestamp": datetime.utcnow().isoformat(),
            "guild_id": guild_id,
            "user_id": user_id,
            "action": action,
            "details": details
        }
        
        log_data.append(log_entry)
        self.save_json(log_file, log_data)

    @app_commands.command(name="set-modrole", description="Set a role as a bot mod role")
    @app_commands.describe(mod_role="The role to set as a bot mod role")
    async def set_modrole(self, interaction: discord.Interaction, mod_role: discord.Role):
        """Set a role as a bot mod role."""
        # CWV - Check if the user has administrator permissions
        if not interaction.user.guild_permissions.administrator:
            await interaction.response.send_message(embed=discord.Embed(
                title="Permission Denied",
                description="You do not have the required permissions to use this command.",
                color=discord.Color.red()
            ), ephemeral=True)
            return

        mod_file = './json/mod.json'
        mod_data = self.load_json(mod_file, {})

        guild_id = str(interaction.guild.id)
        if guild_id not in mod_data:
            mod_data[guild_id] = {"roles": []}

        # CWV - Check if the role is already set as a bot mod role
        if mod_role.id in mod_data[guild_id]["roles"]:
            await interaction.response.send_message(embed=discord.Embed(
                title="Error",
                description=f"The role {mod_role.mention} is already set as a bot mod role.",
                color=discord.Color.red()
            ), ephemeral=True)
            return

        # CWV - Add the role to the mod roles list
        mod_data[guild_id]["roles"].append(mod_role.id)
        self.save_json(mod_file, mod_data)

        # CWV - Log the event
        log_details = {
            "action": "set_modrole",
            "role_id": mod_role.id,
            "role_name": mod_role.name
        }
        self.log_event(guild_id, str(interaction.user.id), "set_modrole", log_details)

        # CWV - Send success message
        await interaction.response.send_message(embed=discord.Embed(
            title="Mod Role Set",
            description=f"The role {mod_role.mention} has been set as a bot mod role.",
            color=discord.Color.green()
        ))

async def setup(bot):
    await bot.add_cog(SetModRole(bot))
