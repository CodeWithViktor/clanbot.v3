import discord
from discord import app_commands
from discord.ext import commands
import json

class MultiplierInfo(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    def load_json(self, filepath, default):
        try:
            with open(filepath, 'r') as f:
                return json.load(f)
        except FileNotFoundError:
            return default

    def get_mod(self, user_id, guild_id):
        # CWV - Load mod users and roles
        mod_user_file = './json/moduser.json'
        mod_role_file = './json/mod.json'
        mod_user_data = self.load_json(mod_user_file, {})
        mod_role_data = self.load_json(mod_role_file, {})

        # CWV - Check if the user is a mod user or has a mod role
        if str(guild_id) in mod_user_data and user_id in mod_user_data[str(guild_id)]["users"]:
            return True

        if str(guild_id) in mod_role_data:
            return any(role.id in mod_role_data[str(guild_id)]["roles"] for role in self.bot.get_guild(guild_id).roles)

        return False

    @app_commands.command(name="multiplier-info", description="Get information about the current ongoing multiplier for the server")
    async def multiplier_info(self, interaction: discord.Interaction):
        guild_id = str(interaction.guild.id)

        # CWV - Load multiplier data
        multiplier_file = './json/multiplier.json'
        multiplier_data = self.load_json(multiplier_file, {})

        if guild_id not in multiplier_data or not multiplier_data[guild_id]:
            await interaction.response.send_message(embed=discord.Embed(
                title="📉 No Multiplier Active",
                description="There is currently no active multiplier for this server.",
                color=discord.Color.red()
            ), ephemeral=True)
            return

        # CWV - Get details of the current multipliers
        current_multipliers = multiplier_data[guild_id]
        mod_id = None
        for event, multiplier in current_multipliers.items():
            if event != 'default':
                mod_id = multiplier.get('mod_id')
                break

        # CWV - If there's a multiplier set for events
        if mod_id:
            mod = interaction.guild.get_member(int(mod_id)) if mod_id else None
            mod_name = mod.mention if mod else "Unknown"
            multiplier_amount = current_multipliers.get(event, "N/A")
            description = (f"**Event**: {event}\n"
                           f"**Amount**: {multiplier_amount}x\n"
                           f"**Set By**: {mod_name}")
        else:
            mod_id = next(iter(current_multipliers.values())).get('mod_id')
            mod = interaction.guild.get_member(int(mod_id)) if mod_id else None
            mod_name = mod.mention if mod else "Unknown"
            multiplier_amount = current_multipliers.get('default', "N/A")
            description = (f"**Default Multiplier**: {multiplier_amount}x\n"
                           f"**Set By**: {mod_name}")

        # CWV - Create and send the embed
        embed = discord.Embed(
            title="📈 Current Multiplier Info",
            description=description,
            color=discord.Color.blue()
        )
        await interaction.response.send_message(embed=embed)

async def setup(bot):
    await bot.add_cog(MultiplierInfo(bot))
