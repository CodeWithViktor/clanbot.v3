import discord
from discord import app_commands
from discord.ext import commands
import json
from datetime import datetime  # CWV - Import datetime for timestamping logs

class RemoveModUser(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    def load_json(self, filepath, default):
        try:
            with open(filepath, 'r') as f:
                return json.load(f)
        except FileNotFoundError:
            return default

    def save_json(self, filepath, data):
        with open(filepath, 'w') as f:
            json.dump(data, f, indent=4)

    def log_event(self, guild_id, user_id, action, details):
        """Log events to a file."""
        log_file = './json/event_logs.json'
        log_data = self.load_json(log_file, [])

        log_entry = {
            "timestamp": datetime.utcnow().isoformat(),
            "guild_id": guild_id,
            "user_id": user_id,
            "action": action,
            "details": details
        }
        
        log_data.append(log_entry)
        self.save_json(log_file, log_data)

    @app_commands.command(name="remove-moduser", description="Remove a user from the bot mod list")
    @app_commands.describe(mod_user="The user to remove from the bot mod list")
    async def remove_moduser(self, interaction: discord.Interaction, mod_user: discord.User):
        # CWV - Check if the user has administrator permissions
        if not interaction.user.guild_permissions.administrator:
            await interaction.response.send_message(embed=discord.Embed(
                title="Permission Denied",
                description="You do not have the required permissions to use this command.",
                color=discord.Color.red()
            ), ephemeral=True)
            return

        mod_file = './json/moduser.json'
        mod_data = self.load_json(mod_file, {})

        guild_id = str(interaction.guild.id)
        if guild_id not in mod_data or mod_user.id not in mod_data[guild_id].get("users", []):
            await interaction.response.send_message(embed=discord.Embed(
                title="User Not Found",
                description=f"The user {mod_user.mention} is not a bot mod.",
                color=discord.Color.red()
            ), ephemeral=True)
            return

        # CWV - Remove the user from the bot mod list
        mod_data[guild_id]["users"].remove(mod_user.id)
        if not mod_data[guild_id]["users"]:
            del mod_data[guild_id]

        # CWV - Save updated mod user data
        self.save_json(mod_file, mod_data)

        # CWV - Log the event
        log_details = {
            "action": "remove_moduser",
            "status": "success",
            "user": mod_user.id,
            "user_name": str(mod_user)
        }
        self.log_event(guild_id, interaction.user.id, "remove_moduser", log_details)

        # CWV - Send success message
        await interaction.response.send_message(embed=discord.Embed(
            title="Mod User Removed",
            description=f"The user {mod_user.mention} has been removed from the bot mod list.",
            color=discord.Color.green()
        ))

async def setup(bot):
    await bot.add_cog(RemoveModUser(bot))
