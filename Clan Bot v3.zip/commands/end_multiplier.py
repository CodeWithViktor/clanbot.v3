import discord
from discord import app_commands
from discord.ext import commands
import json
import datetime 

class EndMultiplier(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    def load_json(self, filepath, default):
        try:
            with open(filepath, 'r') as f:
                return json.load(f)
        except FileNotFoundError:
            return default

    def save_json(self, filepath, data):
        with open(filepath, 'w') as f:
            json.dump(data, f, indent=4)

    def log_event(self, guild_id, user_id, action, details):
        """Log events to a file."""
        log_file = './json/event_logs.json'
        log_data = self.load_json(log_file, [])

        log_entry = {
            "timestamp": datetime.utcnow().isoformat(),
            "guild_id": guild_id,
            "user_id": user_id,
            "action": action,
            "details": details
        }
        
        log_data.append(log_entry)
        self.save_json(log_file, log_data)

    def is_mod(self, guild_id, user):
        # CWV - Load mod users and roles
        mod_user_file = './json/moduser.json'
        mod_role_file = './json/mod.json'
        mod_user_data = self.load_json(mod_user_file, {})
        mod_role_data = self.load_json(mod_role_file, {})

        # CWV - Check if the user is a mod user or has a mod role
        if str(guild_id) in mod_user_data and user.id in mod_user_data[str(guild_id)]["users"]:
            return True

        if str(guild_id) in mod_role_data:
            for role in user.roles:
                if role.id in mod_role_data[str(guild_id)]["roles"]:
                    return True

        return False

    @app_commands.command(name="end-multiplier", description="End the ongoing points multiplier for the server")
    async def end_multiplier(self, interaction: discord.Interaction):
        guild_id = str(interaction.guild.id)
        user = interaction.user

        if not self.is_mod(guild_id, user):
            await interaction.response.send_message(embed=discord.Embed(
                title="Permission Denied",
                description="You do not have permission to use this command.",
                color=discord.Color.red()
            ), ephemeral=True)
            return

        # CWV - Load existing multiplier data
        multiplier_file = './json/multiplier.json'
        multiplier_data = self.load_json(multiplier_file, {})

        if guild_id not in multiplier_data or not multiplier_data[guild_id]:
            await interaction.response.send_message(embed=discord.Embed(
                title="No Active Multiplier",
                description="There is no active multiplier to end.",
                color=discord.Color.red()
            ), ephemeral=True)
            return

        # CWV - End the multiplier
        description = ""
        if 'default' in multiplier_data[guild_id]:
            del multiplier_data[guild_id]['default']
            description = "Default multiplier has been ended."

        # CWV - Remove event-based multipliers
        if not description:  # CWV - Only set description if no default multiplier was present
            description = "The event-based multipliers have been ended."

        del multiplier_data[guild_id]  # CWV - Remove the guild entry if no multipliers remain

        # CWV - Save updated multiplier data
        self.save_json(multiplier_file, multiplier_data)

        # CWV - Log the event
        log_details = {
            "action": "end_multiplier",
            "status": "success",
            "description": description
        }
        self.log_event(guild_id, user.id, "end_multiplier", log_details)

        # CWV - Send the success message as a response to the interaction
        await interaction.response.send_message(embed=discord.Embed(
            title="Multiplier Ended",
            description=description,
            color=discord.Color.green()
        ))

async def setup(bot):
    await bot.add_cog(EndMultiplier(bot))
