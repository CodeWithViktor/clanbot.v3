import discord
from discord.ext import commands
from discord import app_commands
from discord.ui import Button, View, Select
import json
import math
from datetime import datetime

class MonthlyLeaderboard(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name='monthlylb', description='Displays the top players in the server for the current month.')
    async def monthlylb(self, interaction: discord.Interaction):
        # CWV - Load scores and wins data
        with open('json/scores.json', 'r') as f:
            scores = json.load(f)
        with open('json/wins.json', 'r') as f:
            wins = json.load(f)

        server_id = str(interaction.guild.id)
        if server_id not in scores:
            await interaction.response.send_message('No data available for this server.')
            return

        server_scores = scores[server_id]
        server_wins = wins.get(server_id, {})

        # CWV - Get the current month and year
        current_month = datetime.now().strftime('%Y-%m')

        # CWV - Get all months with available data
        available_months = set()
        for user_data in server_scores.values():
            for date in user_data['dates']:
                available_months.add(date[:7])  # CWV - Extract the 'YYYY-MM' format
        available_months = sorted(available_months, reverse=True)

        # CWV - Format the months as "Month Year"
        def format_month_year(ym):
            year, month = ym.split('-')
            return datetime(int(year), int(month), 1).strftime('%B %Y')  # CWV - E.g., "August 2024"

        # CWV - Create dictionaries to store the total points and wins for the current month
        def get_data_for_month(selected_month):
            all_points = {}
            all_wins = {}

            # CWV - Filter the scores for the selected month
            for user_id, user_data in server_scores.items():
                monthly_points = sum(points for date, points in user_data['dates'].items() if date.startswith(selected_month))
                if monthly_points > 0:
                    all_points[user_id] = monthly_points

            # CWV - Filter the wins for the selected month
            for user_id, user_data in server_wins.items():
                monthly_wins = sum(wins for date, wins in user_data['dates'].items() if date.startswith(selected_month))
                if monthly_wins > 0:
                    all_wins[user_id] = monthly_wins

            return all_points, all_wins

        # CWV - Get the initial data for the current month
        all_points, all_wins = get_data_for_month(current_month)
        sorted_points = sorted(all_points.items(), key=lambda x: x[1], reverse=True)
        sorted_wins = sorted(all_wins.items(), key=lambda x: x[1], reverse=True)

        leaderboard_type = "points"
        page = 1
        max_pages_points = math.ceil(len(sorted_points) / 10)
        max_pages_wins = math.ceil(len(sorted_wins) / 10)

        # CWV - Define the view with dropdown and buttons
        class MonthlyLeaderboardView(View):
            def __init__(self, interaction, leaderboard_type, page, selected_month):
                super().__init__(timeout=180)
                self.interaction = interaction
                self.leaderboard_type = leaderboard_type
                self.page = page
                self.selected_month = selected_month
                self.update_buttons()
                self.update_dropdown()

            def update_buttons(self):
                max_pages = max_pages_points if self.leaderboard_type == "points" else max_pages_wins
                self.previous_page.disabled = self.page == 1
                self.next_page.disabled = self.page == max_pages
                self.wins_leaderboard.label = "Wins Leaderboard" if self.leaderboard_type == "points" else "Points Leaderboard"

            def update_dropdown(self):
                # CWV - Populate the dropdown with available months in "Month Year" format
                self.month_selector.options = [
                    discord.SelectOption(label=format_month_year(month), value=month, default=(month == self.selected_month))
                    for month in available_months
                ]

            async def update_message(self):
                all_points, all_wins = get_data_for_month(self.selected_month)
                sorted_points = sorted(all_points.items(), key=lambda x: x[1], reverse=True)
                sorted_wins = sorted(all_wins.items(), key=lambda x: x[1], reverse=True)

                if self.leaderboard_type == "points":
                    data = sorted_points
                    description = '\n'.join(
                        f"{(self.page-1)*10 + i + 1}. <@{user_id}> - {score} points"
                        for i, (user_id, score) in enumerate(data[(self.page-1)*10:self.page*10])
                    )
                    title = f"{self.interaction.guild.name} {format_month_year(self.selected_month)} Points Leaderboard"
                else:
                    data = sorted_wins
                    description = '\n'.join(
                        f"{(self.page-1)*10 + i + 1}. <@{user_id}> - {wins} wins"
                        for i, (user_id, wins) in enumerate(data[(self.page-1)*10:self.page*10])
                    )
                    title = f"{self.interaction.guild.name} {format_month_year(self.selected_month)} Wins Leaderboard"

                embed = discord.Embed(title=title, description=description, color=discord.Color.gold())
                embed.set_thumbnail(url=self.interaction.guild.icon.url)

                try:
                    await self.interaction.edit_original_response(embed=embed, view=self)
                except discord.NotFound:
                    pass

            @discord.ui.button(label="⬅️ Previous Page", style=discord.ButtonStyle.secondary, disabled=True)
            async def previous_page(self, interaction: discord.Interaction, button: Button):
                if self.page > 1:
                    self.page -= 1
                    self.update_buttons()
                    await self.update_message()
                    await interaction.response.defer()

            @discord.ui.button(label="🏆 Wins Leaderboard", style=discord.ButtonStyle.primary)
            async def wins_leaderboard(self, interaction: discord.Interaction, button: Button):
                if self.leaderboard_type == "points":
                    self.leaderboard_type = "wins"
                else:
                    self.leaderboard_type = "points"
                self.page = 1
                self.update_buttons()
                await self.update_message()
                await interaction.response.defer()

            @discord.ui.button(label="Next Page ➡️", style=discord.ButtonStyle.secondary, disabled=True)
            async def next_page(self, interaction: discord.Interaction, button: Button):
                max_pages = max_pages_points if self.leaderboard_type == "points" else max_pages_wins
                if self.page < max_pages:
                    self.page += 1
                    self.update_buttons()
                    await self.update_message()
                    await interaction.response.defer()

            @discord.ui.select(placeholder="Select a month", options=[], row=1)
            async def month_selector(self, interaction: discord.Interaction, select: Select):
                self.selected_month = select.values[0]
                self.page = 1  # CWV - Reset to the first page when changing the month
                self.update_buttons()
                await self.update_message()
                await interaction.response.defer()

        view = MonthlyLeaderboardView(interaction, leaderboard_type, page, current_month)
        await interaction.response.send_message(embed=discord.Embed(title=f"{interaction.guild.name} Monthly Leaderboard", description="Fetching data...", color=discord.Color.gold()), view=view)
        await view.update_message()

async def setup(bot):
    await bot.add_cog(MonthlyLeaderboard(bot))
