import discord
from discord import app_commands
from discord.ext import commands
import json
import os
import datetime

class RewardRole(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    def load_json(self, filepath, default):
        """Load JSON data from a file, return default if file does not exist."""
        try:
            with open(filepath, 'r') as f:
                return json.load(f)
        except FileNotFoundError:
            return default

    def save_json(self, filepath, data):
        """Save JSON data to a file."""
        with open(filepath, 'w') as f:
            json.dump(data, f, indent=4)

    def is_mod(self, guild_id, user_id):
        """Check if a user is a mod based on the mod files."""
        mod_users_file = './json/moduser.json'
        mod_roles_file = './json/mod.json'

        # CWV - Load mod data
        mod_users = self.load_json(mod_users_file, {}).get(guild_id, {}).get("users", [])
        mod_roles = self.load_json(mod_roles_file, {}).get(guild_id, {}).get("roles", [])

        # CWV - Check if the user is in the mod list for the guild or has a mod role
        member = self.bot.get_guild(int(guild_id)).get_member(int(user_id))
        
        # CWV - If the user is in the mod_users list or has a mod role, return True
        return str(user_id) in mod_users or (member and any(role.id in mod_roles for role in member.roles))

    def log_event(self, guild_id, user_id, action, details):
        """Log events to a file."""
        log_file = './json/event_logs.json'
        log_data = self.load_json(log_file, [])

        log_entry = {
            "timestamp": datetime.datetime.utcnow().isoformat(),
            "guild_id": guild_id,
            "user_id": user_id,
            "action": action,
            "details": details
        }
        
        log_data.append(log_entry)
        self.save_json(log_file, log_data)

    @app_commands.command(name="reward-role", description="Set up reward roles based on points or wins.")
    @app_commands.describe(
        type="The type of reward ('points' or 'wins')",
        amount="The amount of points or wins required",
        role="The role to be awarded",
        channel="The channel where notifications will be sent"
    )
    async def reward_role(self, interaction: discord.Interaction, type: str, amount: int, role: discord.Role, channel: discord.TextChannel):
        """Set up a reward role with specified type, amount, and channel."""
        guild_id = str(interaction.guild.id)
        user_id = str(interaction.user.id)

        # CWV - Check if the user has mod permissions
        if not self.is_mod(guild_id, user_id):
            await interaction.response.send_message(embed=discord.Embed(
                title="Permission Denied",
                description="You do not have the required permissions to use this command.",
                color=discord.Color.red()
            ), ephemeral=True)
            return

        # CWV - Validate input
        type = type.lower()
        if type not in ['points', 'wins']:
            await interaction.response.send_message(embed=discord.Embed(
                title="Invalid Type",
                description="The 'type' argument must be 'points' or 'wins'.",
                color=discord.Color.red()
            ), ephemeral=True)
            return

        if amount <= 0:
            await interaction.response.send_message(embed=discord.Embed(
                title="Invalid Amount",
                description="The 'amount' must be a positive integer.",
                color=discord.Color.red()
            ), ephemeral=True)
            return

        # CWV - Load existing data
        reward_file = './json/reward_roles.json'
        reward_data = self.load_json(reward_file, {})

        # CWV - Update the data with new reward role settings
        if guild_id not in reward_data:
            reward_data[guild_id] = {}

        reward_data[guild_id][str(role.id)] = {
            "type": type.capitalize(),
            "amount": amount,
            "channel_id": channel.id
        }

        # CWV - Save updated data
        self.save_json(reward_file, reward_data)

        # CWV - Log the event
        log_details = {
            "action": "reward_role",
            "type": type,
            "amount": amount,
            "role_id": role.id,
            "role_name": role.name,
            "channel_id": channel.id,
            "channel_name": channel.name
        }
        self.log_event(guild_id, user_id, "reward_role", log_details)

        await interaction.response.send_message(embed=discord.Embed(
            title="Reward Role Set",
            description=f"The role {role.mention} has been set to reward users for {type} reaching {amount}. Notifications will be sent to {channel.mention}.",
            color=discord.Color.green()
        ))

async def setup(bot):
    await bot.add_cog(RewardRole(bot))
