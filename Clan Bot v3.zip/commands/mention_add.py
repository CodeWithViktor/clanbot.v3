import discord
from discord.ext import commands
import json
from datetime import datetime
import os

class MentionAdd(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    # CWV - Load or initialize JSON files
    def load_json(self, filepath, default):
        if not os.path.exists(filepath):
            return default
        with open(filepath, 'r') as f:
            return json.load(f)

    def save_json(self, filepath, data):
        with open(filepath, 'w') as f:
            json.dump(data, f, indent=4)

    def log_event(self, guild_id, user_id, action, details):
        """Log events to a file."""
        log_file = './json/event_logs.json'
        log_data = self.load_json(log_file, [])

        log_entry = {
            "timestamp": datetime.utcnow().isoformat(),
            "guild_id": guild_id,
            "user_id": user_id,
            "action": action,
            "details": details
        }
        
        log_data.append(log_entry)
        self.save_json(log_file, log_data)

    @commands.Cog.listener()
    async def on_message(self, message: discord.Message):
        # CWV - Ignore bot messages and command invocations
        if message.author.bot or message.content.startswith(tuple(self.bot.command_prefix)):
            return  # CWV - Skip if the bot sent the message or if it's a command

        # CWV - Check if the bot is mentioned and there's a number following the mention
        if self.bot.user in message.mentions:
            try:
                points = float(message.content.split()[-1])  # CWV - Extract points (last word in the message)
            except ValueError:
                return  # CWV - Ignore if the last word isn't a number

            if points <= 0 or points > 750 or len(str(points).split(".")[1]) > 2:
                await message.channel.send("Please enter a positive number with up to two decimal places, and the maximum is 750.", delete_after=10)
                return

            user_id = str(message.author.id)
            guild_id = str(message.guild.id)
            current_date = str(datetime.utcnow().date())

            scores_file = './json/scores.json'
            wins_file = './json/wins.json'
            multiplier_file = './json/multiplier.json'

            # CWV - Load scores, wins, and multiplier data
            scores_data = self.load_json(scores_file, {})
            wins_data = self.load_json(wins_file, {})
            multiplier_data = self.load_json(multiplier_file, {})

            # CWV - Determine the multiplier for the server (if set)
            multiplier = multiplier_data.get(guild_id, {}).get('default', 1)  # CWV - Default multiplier is 1
            adjusted_points = points * multiplier  # CWV - Apply multiplier to the points

            # CWV - Update score in scores.json
            if guild_id not in scores_data:
                scores_data[guild_id] = {}
            if user_id not in scores_data[guild_id]:
                scores_data[guild_id][user_id] = {"total": 0, "dates": {}}

            # CWV - Update total points and points for the current date
            scores_data[guild_id][user_id]["total"] += adjusted_points
            if current_date in scores_data[guild_id][user_id]["dates"]:
                scores_data[guild_id][user_id]["dates"][current_date] += adjusted_points
            else:
                scores_data[guild_id][user_id]["dates"][current_date] = adjusted_points

            # CWV - Update wins in wins.json
            if guild_id not in wins_data:
                wins_data[guild_id] = {}
            if user_id not in wins_data[guild_id]:
                wins_data[guild_id][user_id] = {"total": 0, "dates": {}}

            # CWV - Increment total wins and wins for the current date
            wins_data[guild_id][user_id]["total"] += 1
            if current_date in wins_data[guild_id][user_id]["dates"]:
                wins_data[guild_id][user_id]["dates"][current_date] += 1
            else:
                wins_data[guild_id][user_id]["dates"][current_date] = 1

            # CWV - Save updated data to files
            self.save_json(scores_file, scores_data)
            self.save_json(wins_file, wins_data)

            # CWV - Prepare an embed message
            embed = discord.Embed(
                title=f"Points added in {message.guild.name}",
                color=discord.Color.green()
            )

            # CWV - Check if the multiplier was applied and customize the message
            if multiplier > 1:
                embed.description = (f"Added **{points}** points (multiplied by **{multiplier}**) to your score, resulting in **{adjusted_points}** points.\n"
                                     f"Your new total score is **{scores_data[guild_id][user_id]['total']}** points.\n"
                                     f"Your total Battle Wins are **{wins_data[guild_id][user_id]['total']}** wins.")
            else:
                embed.description = (f"Added **{points}** points to your score.\n"
                                     f"Your new total score is **{scores_data[guild_id][user_id]['total']}** points.\n"
                                     f"Your total Battle Wins are **{wins_data[guild_id][user_id]['total']}** wins.")

            # CWV - Set the author with the user's avatar and username
            embed.set_author(name=message.author.name, icon_url=message.author.avatar.url)

            # CWV - Footer
            embed.set_footer(text="~ Made with ❤️ by CWV")

            # CWV - Respond to the user
            await message.channel.send(embed=embed)

            # CWV - Log the event
            log_details = {
                "points_added": points,
                "adjusted_points": adjusted_points,
                "new_total_score": scores_data[guild_id][user_id]["total"],
                "total_wins": wins_data[guild_id][user_id]["total"]
            }
            self.log_event(guild_id, user_id, "mention_add", log_details)

        # CWV - Ensure the bot processes other commands after handling the mention
        await self.bot.process_commands(message)

async def setup(bot):
    await bot.add_cog(MentionAdd(bot))
