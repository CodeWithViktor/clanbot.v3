import discord
from discord import app_commands
from discord.ext import commands

class HelpCommand(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="help", description="Get help with the bot")
    async def help(self, interaction: discord.Interaction):
        embed = discord.Embed(
            title="TT.io Clan Bot - Command Guide",
            description="Welcome to the help menu! Here's a list of available commands:",
            color=0x7289da  # CWV - Discord Blurple color
        )

        command_categories = [
            {
                'name': 'Economy',
                'emoji': '💰',
                'commands': [
                    ('`/add`', 'Register points to your balance'),
                    ('`/remove`', 'De-register points from your balance'),
                    ('`/profile`', 'Check your profile'),
                    ('`/addscore`', 'Register points for someone else (Mod only)'),
                    ('`/removescore`', 'De-register points for someone else (Mod only)'),
                    ('`/addwin`', 'Register a win for someone (Mod only)'),
                    ('`/removewin`', 'De-register a win for someone (Mod only)'),
                ]
            },
            {
                'name': 'Leaderboard',
                'emoji': '📊',
                'commands': [
                    ('`/leaderboard`', 'View points and wins leaderboard'),
                    ('`/monthlylb`', 'View monthly leaderboard'),
                    ('`@bot <days>d`', 'Show leaderboard for last X days'),
                ]
            },
            {
                'name': 'Reward Roles',
                'emoji': '🎖️',
                'commands': [
                    ('`/rewardroles`', 'Add a reward role (Mod only)'),
                    ('`/removerewardrole`', 'Remove a reward role (Mod only)'),
                    ('`/roles`', 'View available reward roles'),
                ]
            },
            {
                'name': 'Multiplier',
                'emoji': '✖️',
                'commands': [
                    ('`/multiplier-info`', 'View current multiplier info'),
                    ('`/multiplier`', 'Set a multiplier (Mod only)'),
                    ('`/end-multiplier`', 'End the current multiplier (Mod only)'),
                ]
            },
            {
                'name': 'Moderation',
                'emoji': '🛡️',
                'commands': [
                    ('`/set-modrole`', 'Set a moderator role (Admin only)'),
                    ('`/set-moduser`', 'Set a moderator user (Admin only)'),
                    ('`/remove-modrole`', 'Remove a moderator role (Admin only)'),
                    ('`/remove-moduser`', 'Remove a moderator user (Admin only)'),
                    ('`/mod-info`', 'View moderator information'),
                ]
            },
            {
                'name': 'Miscellaneous',
                'emoji': '🔧',
                'commands': [
                    ('`/server-info`', 'View server bot settings'),
                    ('`/about`', 'View bot information'),
                    ('`@bot <points>`', 'Quick-add points to your balance'),
                ]
            },
        ]

        for category in command_categories:
            commands_text = "\n".join([f"{cmd[0]} • {cmd[1]}" for cmd in category['commands']])
            embed.add_field(
                name=f"{category['emoji']} {category['name']}",
                value=commands_text,
                inline=False
            )

        embed.set_footer(text="Made with ❤️ by CWV | Use /help <command> for more details on a specific command")
        
        if self.bot.user.avatar:
            embed.set_thumbnail(url=self.bot.user.avatar.url)

        await interaction.response.send_message(embed=embed)

async def setup(bot: commands.Bot):
    await bot.add_cog(HelpCommand(bot))
