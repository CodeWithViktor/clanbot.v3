import discord
from discord.ext import commands
from discord import app_commands
from discord.ui import Button, View
import json
import math
import asyncio

class Leaderboard(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name='leaderboard', description='Displays the top players in the server with the highest score.')
    async def leaderboard(self, interaction: discord.Interaction):
        # CWV - Load scores and wins data
        with open('json/scores.json', 'r') as f:
            scores = json.load(f)
        with open('json/wins.json', 'r') as f:
            wins = json.load(f)

        server_id = str(interaction.guild.id)
        if server_id not in scores:
            await interaction.response.send_message('No data available for this server.')
            return

        server_scores = scores[server_id]
        server_wins = wins.get(server_id, {})

        # CWV - Create dictionaries to store the total points and wins of all members
        all_points = {user_id: sum(user_data['dates'].values()) for user_id, user_data in server_scores.items()}
        all_wins = {user_id: sum(user_data['dates'].values()) for user_id, user_data in server_wins.items()}

        # CWV - Sort the points and wins
        sorted_points = sorted(all_points.items(), key=lambda x: x[1], reverse=True)
        sorted_wins = sorted(all_wins.items(), key=lambda x: x[1], reverse=True)

        # CWV - Initialize leaderboard type and page number
        leaderboard_type = "points"
        page = 1
        max_pages_points = math.ceil(len(sorted_points) / 10)
        max_pages_wins = math.ceil(len(sorted_wins) / 10)

        # CWV - Define the view and buttons
        class LeaderboardView(View):
            def __init__(self, interaction, leaderboard_type, page):
                super().__init__(timeout=180)
                self.interaction = interaction
                self.leaderboard_type = leaderboard_type
                self.page = page
                self.update_buttons()

            def update_buttons(self):
                # CWV - Get the max pages for the current leaderboard
                max_pages = max_pages_points if self.leaderboard_type == "points" else max_pages_wins

                # CWV - Enable/disable the buttons based on the page number
                self.previous_page.disabled = self.page == 1
                self.next_page.disabled = self.page == max_pages
                self.wins_leaderboard.label = "Wins Leaderboard" if self.leaderboard_type == "points" else "Points Leaderboard"

            async def update_message(self):
                if self.leaderboard_type == "points":
                    data = sorted_points
                    description = '\n'.join(
                        f"{(self.page-1)*10 + i + 1}. <@{user_id}> - {score} points"
                        for i, (user_id, score) in enumerate(data[(self.page-1)*10:self.page*10])
                    )
                    title = f"{self.interaction.guild.name} Points Leaderboard"
                else:
                    data = sorted_wins
                    description = '\n'.join(
                        f"{(self.page-1)*10 + i + 1}. <@{user_id}> - {wins} wins"
                        for i, (user_id, wins) in enumerate(data[(self.page-1)*10:self.page*10])
                    )
                    title = f"{self.interaction.guild.name} Wins Leaderboard"

                embed = discord.Embed(title=title, description=description, color=discord.Color.gold())
                embed.set_thumbnail(url=self.interaction.guild.icon.url)

                # CWV - Update the message
                try:
                    await self.interaction.edit_original_response(embed=embed, view=self)
                except discord.NotFound:
                    # CWV - Handle case where the original message might be deleted
                    pass

            @discord.ui.button(label="⬅️ Previous Page", style=discord.ButtonStyle.secondary, disabled=True)
            async def previous_page(self, interaction: discord.Interaction, button: Button):
                if self.page > 1:
                    self.page -= 1
                    self.update_buttons()  # CWV - Update button states
                    await self.update_message()
                    await interaction.response.defer()

            @discord.ui.button(label="🏆 Wins Leaderboard", style=discord.ButtonStyle.primary)
            async def wins_leaderboard(self, interaction: discord.Interaction, button: Button):
                # CWV - Toggle between points and wins leaderboard
                if self.leaderboard_type == "points":
                    self.leaderboard_type = "wins"
                else:
                    self.leaderboard_type = "points"
                self.page = 1  # CWV - Reset to the first page
                
                self.update_buttons()  # CWV - Immediately update the button label and disable state
                await self.update_message()  # CWV - Update the message content
                await interaction.response.defer()

            @discord.ui.button(label="Next Page ➡️", style=discord.ButtonStyle.secondary, disabled=True)
            async def next_page(self, interaction: discord.Interaction, button: Button):
                max_pages = max_pages_points if self.leaderboard_type == "points" else max_pages_wins
                if self.page < max_pages:
                    self.page += 1
                    self.update_buttons()  # CWV - Update button states
                    await self.update_message()
                    await interaction.response.defer()

        view = LeaderboardView(interaction, leaderboard_type, page)
        await interaction.response.send_message(embed=discord.Embed(title=f"{interaction.guild.name} Leaderboard", description="Fetching data...", color=discord.Color.gold()), view=view)
        await view.update_message()

async def setup(bot):
    await bot.add_cog(Leaderboard(bot))
