import discord
from discord import app_commands
from discord.ext import commands
import json
from datetime import datetime

class SetModUser(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    def load_json(self, filepath, default):
        """Load JSON data from a file, return default if file does not exist."""
        try:
            with open(filepath, 'r') as f:
                return json.load(f)
        except FileNotFoundError:
            return default

    def save_json(self, filepath, data):
        """Save JSON data to a file."""
        with open(filepath, 'w') as f:
            json.dump(data, f, indent=4)

    def log_event(self, guild_id, user_id, action, details):
        """Log events to a file."""
        log_file = './json/event_logs.json'
        log_data = self.load_json(log_file, [])

        log_entry = {
            "timestamp": datetime.utcnow().isoformat(),
            "guild_id": guild_id,
            "user_id": user_id,
            "action": action,
            "details": details
        }
        
        log_data.append(log_entry)
        self.save_json(log_file, log_data)

    @app_commands.command(name="set-moduser", description="Set a user as a bot mod")
    @app_commands.describe(mod_user="The user to set as a bot mod")
    async def set_moduser(self, interaction: discord.Interaction, mod_user: discord.User):
        """Set a user as a bot mod."""
        # CWV - Check if the user has administrator permissions
        if not interaction.user.guild_permissions.administrator:
            await interaction.response.send_message(embed=discord.Embed(
                title="Permission Denied",
                description="You do not have the required permissions to use this command.",
                color=discord.Color.red()
            ), ephemeral=True)
            return

        mod_file = './json/moduser.json'
        mod_data = self.load_json(mod_file, {})

        guild_id = str(interaction.guild.id)
        if guild_id not in mod_data:
            mod_data[guild_id] = {"users": []}

        # CWV - Check if the user is already a bot mod
        if mod_user.id in mod_data[guild_id]["users"]:
            await interaction.response.send_message(embed=discord.Embed(
                title="Error",
                description=f"The user {mod_user.mention} is already a bot mod.",
                color=discord.Color.red()
            ), ephemeral=True)
            return

        # CWV - Add the user to the mod list
        mod_data[guild_id]["users"].append(mod_user.id)
        self.save_json(mod_file, mod_data)

        # CWV - Prepare DM message
        embed = discord.Embed(
            title="You Are Now a Bot Mod",
            description=f"You have been appointed as a bot mod for {interaction.guild.name} by {interaction.user.mention}.",
            color=discord.Color.blue()
        )
        try:
            await mod_user.send(embed=embed)
        except discord.Forbidden:
            await interaction.response.send_message(embed=discord.Embed(
                title="Error",
                description=f"Failed to send a DM to {mod_user.mention}. They may have DMs disabled.",
                color=discord.Color.red()
            ), ephemeral=True)
            return

        # CWV - Log the event
        log_details = {
            "action": "set_moduser",
            "user_id": mod_user.id,
            "user_name": mod_user.name
        }
        self.log_event(guild_id, str(interaction.user.id), "set_moduser", log_details)

        # CWV - Send success message
        await interaction.response.send_message(embed=discord.Embed(
            title="Mod User Set",
            description=f"The user {mod_user.mention} has been set as a bot mod.",
            color=discord.Color.green()
        ))

async def setup(bot):
    await bot.add_cog(SetModUser(bot))
