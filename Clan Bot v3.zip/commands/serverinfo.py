import discord
from discord import app_commands
from discord.ext import commands
import json
import os
from datetime import datetime

class ServerInfo(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    def load_json(self, filepath, default):
        """Load JSON data from a file, return default if file does not exist."""
        if not os.path.exists(filepath):
            return default
        with open(filepath, 'r') as f:
            return json.load(f)

    @app_commands.command(name="serverinfo", description="Display detailed information about the server")
    async def serverinfo(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=False)

        guild = interaction.guild
        guild_id = str(guild.id)

        # CWV - Load necessary data
        scores_data = self.load_json('./json/scores.json', {})
        wins_data = self.load_json('./json/wins.json', {})
        multiplier_data = self.load_json('./json/multiplier.json', {})
        reward_roles_data = self.load_json('./json/reward_roles.json', {})

        # CWV - Calculate total points and wins for the server
        total_points = sum(user_data['total'] for user_data in scores_data.get(guild_id, {}).values())
        total_wins = sum(user_data['total'] for user_data in wins_data.get(guild_id, {}).values())

        # CWV - Get current multiplier
        current_multiplier = multiplier_data.get(guild_id, {}).get('default', 1)

        # CWV - Count reward roles
        reward_roles_count = len(reward_roles_data.get(guild_id, {}))

        # CWV - Create embed
        embed = discord.Embed(
            title=f"Server Information: {guild.name}",
            color=discord.Color.blue(),
            timestamp=datetime.utcnow()
        )

        # CWV - Server icon
        if guild.icon:
            embed.set_thumbnail(url=guild.icon.url)

        # CWV - General server info
        embed.add_field(name="📊 General Info", value=(
            f"**Owner:** {guild.owner.mention}\n"
            f"**Created on:** {guild.created_at.strftime('%Y-%m-%d')}\n"
            f"**Member Count:** {guild.member_count}\n"
            f"**Roles:** {len(guild.roles)}\n"
            f"**Channels:** {len(guild.channels)}\n"
            f"**Boost Level:** {guild.premium_tier}"
        ), inline=False)

        # CWV - Bot-specific info
        embed.add_field(name="🤖 Bot Statistics", value=(
            f"**Total Points:** {total_points:,}\n"
            f"**Total Wins:** {total_wins:,}\n"
            f"**Current Multiplier:** {current_multiplier}x\n"
            f"**Reward Roles:** {reward_roles_count}"
        ), inline=False)

        # CWV - Top 3 point earners
        top_points = sorted(scores_data.get(guild_id, {}).items(), key=lambda x: x[1]['total'], reverse=True)[:3]
        top_points_str = "\n".join([f"{idx+1}. <@{user_id}>: {data['total']:,}" for idx, (user_id, data) in enumerate(top_points)])
        embed.add_field(name="🏆 Top 3 Point Earners", value=top_points_str or "No data available", inline=False)

        # CWV - Top 3 winners
        top_wins = sorted(wins_data.get(guild_id, {}).items(), key=lambda x: x[1]['total'], reverse=True)[:3]
        top_wins_str = "\n".join([f"{idx+1}. <@{user_id}>: {data['total']:,}" for idx, (user_id, data) in enumerate(top_wins)])
        embed.add_field(name="🎖️ Top 3 Winners", value=top_wins_str or "No data available", inline=False)

        # CWV - Server features
        if guild.features:
            features_str = ", ".join(feature.replace('_', ' ').title() for feature in guild.features)
            embed.add_field(name="✨ Server Features", value=features_str, inline=False)

        embed.set_footer(text=f"Server ID: {guild.id} | Made with ❤️ by CWV")

        await interaction.followup.send(embed=embed)

    @commands.Cog.listener()
    async def on_ready(self):
        print("ServerInfo cog is ready.")

async def setup(bot):
    await bot.add_cog(ServerInfo(bot))
