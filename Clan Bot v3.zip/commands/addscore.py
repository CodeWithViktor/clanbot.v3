import discord
from discord import app_commands
from discord.ext import commands
import json
from datetime import datetime
import os

class AddScore(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    def load_json(self, filepath, default):
        """Load JSON data from a file, return default if file does not exist."""
        if not os.path.exists(filepath):
            print(f"File not found: {filepath}")
            return default
        try:
            with open(filepath, 'r') as f:
                return json.load(f)
        except json.JSONDecodeError:
            print(f"Error decoding JSON from file: {filepath}")
            return default

    def save_json(self, filepath, data):
        """Save JSON data to a file."""
        try:
            with open(filepath, 'w') as f:
                json.dump(data, f, indent=4)
        except Exception as e:
            print(f"Error saving JSON to file {filepath}: {e}")

    def is_mod(self, interaction: discord.Interaction, guild_id: str, user_id: str):
        """Check if a user is a mod based on the mod files."""
        mods_file = './json/mod.json'
        moduser_file = './json/moduser.json'

        # CWV - Load mod data
        mods_data = self.load_json(mods_file, {})
        moduser_data = self.load_json(moduser_file, {})

        # CWV - Debug logging
        print(f"Checking mod status for user {user_id} in guild {guild_id}")
        print(f"Mods data: {mods_data}")
        print(f"Moduser data: {moduser_data}")

        # CWV - Check if the user's roles include any mod roles
        guild_mod_roles = mods_data.get(str(guild_id), {}).get("roles", [])
        user_roles = [role.id for role in interaction.user.roles]
        is_mod_role = any(role_id in user_roles for role_id in guild_mod_roles)

        # CWV - Check if the user is in the moduser list for the guild
        guild_modusers = moduser_data.get(str(guild_id), {}).get("users", [])
        is_moduser = int(user_id) in guild_modusers

        is_mod = is_mod_role or is_moduser
        print(f"Is user a mod? {is_mod}")

        return is_mod

    async def log_command_usage(self, mod_user, target_user, guild, points_added, adjusted_points, total_points, total_wins):
        """Log command usage to the designated logging channel."""
        log_channel_file = './json/logging_channels.json'
        log_channel_data = self.load_json(log_channel_file, {})

        channel_id = log_channel_data.get(str(guild.id), {}).get("channel_id")
        if channel_id:
            log_channel = self.bot.get_channel(int(channel_id))
            if log_channel:
                try:
                    embed = discord.Embed(
                        title="Command Usage Log",
                        description=(f"**Command:** addscore\n"
                                     f"**Mod User:** {mod_user}\n"
                                     f"**Target User:** {target_user}\n"
                                     f"**Points Added:** {points_added}\n"
                                     f"**Adjusted Points (after multiplier):** {adjusted_points}\n"
                                     f"**Total Points:** {total_points}\n"
                                     f"**Total Wins:** {total_wins}\n"
                                     f"**Channel:** {log_channel.mention}\n"
                                     f"**Time:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"),
                        color=discord.Color.blue()
                    )
                    await log_channel.send(embed=embed)
                except Exception as e:
                    print(f"Failed to send log message: {e}")

    @app_commands.command(name="addscore", description="Allows mods to add any amount of points to a user.")
    @app_commands.describe(user="The user to whom points will be added", points="The number of points to add")
    async def addscore(self, interaction: discord.Interaction, user: discord.User, points: float):
        guild_id = str(interaction.guild.id)
        user_id = str(interaction.user.id)

        # CWV - Detailed logging for debugging
        print(f"addscore command invoked by {user_id} for user {user.id} in guild {guild_id}")

        try:
            if not self.is_mod(interaction, guild_id, user_id):
                await interaction.response.send_message("You don't have permission to use this command.", ephemeral=True)
                print(f"Permission denied for user {user_id}")
                return

            if points <= 0:
                await interaction.response.send_message("Please enter a positive number for points.", ephemeral=True)
                print(f"Invalid points value: {points}")
                return

            target_user_id = str(user.id)
            current_date = str(datetime.utcnow().date())

            # CWV - File paths
            scores_file = './json/scores.json'
            wins_file = './json/wins.json'
            multiplier_file = './json/multiplier.json'

            # CWV - Load existing data with error handling
            try:
                scores_data = self.load_json(scores_file, {})
                wins_data = self.load_json(wins_file, {})
                multiplier_data = self.load_json(multiplier_file, {})
            except Exception as e:
                await interaction.response.send_message(f"Error loading data: {str(e)}", ephemeral=True)
                print(f"Error loading JSON data: {e}")
                return

            # CWV - Determine the multiplier for the server (if set)
            multiplier = multiplier_data.get(guild_id, {}).get('default', 1)
            adjusted_points = points * multiplier

            # CWV - Update scores_data
            if guild_id not in scores_data:
                scores_data[guild_id] = {}
            if target_user_id not in scores_data[guild_id]:
                scores_data[guild_id][target_user_id] = {"total": 0, "dates": {}}

            scores_data[guild_id][target_user_id]["total"] += adjusted_points
            scores_data[guild_id][target_user_id]["dates"][current_date] = scores_data[guild_id][target_user_id]["dates"].get(current_date, 0) + adjusted_points

            # CWV - Update wins_data
            if guild_id not in wins_data:
                wins_data[guild_id] = {}
            if target_user_id not in wins_data[guild_id]:
                wins_data[guild_id][target_user_id] = {"total": 0, "dates": {}}

            # CWV - Save updated data to files
            try:
                self.save_json(scores_file, scores_data)
                self.save_json(wins_file, wins_data)
            except Exception as e:
                await interaction.response.send_message(f"Error saving data: {str(e)}", ephemeral=True)
                print(f"Error saving JSON data: {e}")
                return

            # CWV - Prepare the embed message
            embed = discord.Embed(
                title=f"Points added to {user.name} in {interaction.guild.name}",
                color=discord.Color.green()
            )

            if multiplier > 1:
                embed.description = (f"Added **{points}** points (multiplied by **{multiplier}**) to {user.mention}, "
                                     f"resulting in **{adjusted_points}** points.\n"
                                     f"Their new total points are **{scores_data[guild_id][target_user_id]['total']}**.\n"
                                     f"Their total battle wins are **{wins_data[guild_id][target_user_id]['total']}**.")
            else:
                embed.description = (f"Added **{points}** points to {user.mention}.\n"
                                     f"Their new total points are **{scores_data[guild_id][target_user_id]['total']}**.\n"
                                     f"Their total battle wins are **{wins_data[guild_id][target_user_id]['total']}**.")

            embed.set_author(name=interaction.user.name, icon_url=interaction.user.avatar.url if interaction.user.avatar else None)
            embed.set_footer(text="~ Made with ❤️ by CWV")

            await interaction.response.send_message(embed=embed)

            # CWV - Log the command usage
            await self.log_command_usage(
                interaction.user, 
                user, 
                interaction.guild, 
                points, 
                adjusted_points, 
                scores_data[guild_id][target_user_id]['total'], 
                wins_data[guild_id][target_user_id]['total']
            )

        except Exception as e:
            error_message = f"An unexpected error occurred: {str(e)}"
            await interaction.response.send_message(error_message, ephemeral=True)
            print(f"Unexpected error in addscore command: {e}")

    @commands.Cog.listener()
    async def on_ready(self):
        print("AddScore cog is ready.")

async def setup(bot):
    await bot.add_cog(AddScore(bot))
