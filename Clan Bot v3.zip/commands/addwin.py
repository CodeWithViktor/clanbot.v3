import discord
from discord import app_commands
from discord.ext import commands
import json
from datetime import datetime
import os

class AddWin(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    def load_json(self, filepath, default):
        """Load JSON data from a file, return default if file does not exist."""
        if not os.path.exists(filepath):
            print(f"File not found: {filepath}")
            return default
        try:
            with open(filepath, 'r') as f:
                return json.load(f)
        except json.JSONDecodeError:
            print(f"Error decoding JSON from file: {filepath}")
            return default

    def save_json(self, filepath, data):
        """Save JSON data to a file."""
        try:
            with open(filepath, 'w') as f:
                json.dump(data, f, indent=4)
        except Exception as e:
            print(f"Error saving JSON to file {filepath}: {e}")

    def is_mod(self, interaction: discord.Interaction, guild_id: str, user_id: str):
        """Check if a user is a mod based on the mod files."""
        mods_file = './json/mod.json'
        moduser_file = './json/moduser.json'

        # CWV - Load mod data
        mods_data = self.load_json(mods_file, {})
        moduser_data = self.load_json(moduser_file, {})

        # CWV - Debug logging
        print(f"Checking mod status for user {user_id} in guild {guild_id}")
        print(f"Mods data: {mods_data}")
        print(f"Moduser data: {moduser_data}")

        # CWV - Check if the user's roles include any mod roles
        guild_mod_roles = mods_data.get(str(guild_id), {}).get("roles", [])
        user_roles = [role.id for role in interaction.user.roles]
        is_mod_role = any(role_id in user_roles for role_id in guild_mod_roles)

        # CWV - Check if the user is in the moduser list for the guild
        guild_modusers = moduser_data.get(str(guild_id), {}).get("users", [])
        is_moduser = int(user_id) in guild_modusers

        is_mod = is_mod_role or is_moduser
        print(f"Is user a mod? {is_mod}")

        return is_mod

    async def log_command_usage(self, mod_user, target_user, guild, wins_added, new_total_wins, wins_today):
        """Log command usage to the designated logging channel."""
        log_channel_file = './json/logging_channels.json'
        log_channel_data = self.load_json(log_channel_file, {})

        channel_id = log_channel_data.get(str(guild.id), {}).get("channel_id")
        if channel_id:
            log_channel = self.bot.get_channel(int(channel_id))
            if log_channel:
                try:
                    embed = discord.Embed(
                        title="Command Usage Log",
                        description=(f"**Command:** addwin\n"
                                     f"**Mod User:** {mod_user}\n"
                                     f"**Target User:** {target_user}\n"
                                     f"**Wins Added:** {wins_added}\n"
                                     f"**New Total Wins:** {new_total_wins}\n"
                                     f"**Wins Today:** {wins_today}\n"
                                     f"**Channel:** {log_channel.mention}\n"
                                     f"**Time:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"),
                        color=discord.Color.blue()
                    )
                    await log_channel.send(embed=embed)
                except Exception as e:
                    print(f"Failed to send log message: {e}")

    @app_commands.command(name="addwin", description="Allows mods to add any amount of wins to a user.")
    @app_commands.describe(user="The user to whom wins will be added", wins="The number of wins to add")
    async def addwin(self, interaction: discord.Interaction, user: discord.User, wins: int):
        guild_id = str(interaction.guild.id)
        user_id = str(interaction.user.id)

        # CWV - Detailed logging for debugging
        print(f"addwin command invoked by {user_id} for user {user.id} in guild {guild_id}")

        try:
            if not self.is_mod(interaction, guild_id, user_id):
                await interaction.response.send_message("You don't have permission to use this command.", ephemeral=True)
                print(f"Permission denied for user {user_id}")
                return

            if wins <= 0:
                await interaction.response.send_message("Please enter a positive number for wins.", ephemeral=True)
                print(f"Invalid wins value: {wins}")
                return

            target_user_id = str(user.id)
            current_date = str(datetime.utcnow().date())

            # CWV - File path
            wins_file = './json/wins.json'

            # CWV - Load existing data
            wins_data = self.load_json(wins_file, {})

            # CWV - Update wins_data
            if guild_id not in wins_data:
                wins_data[guild_id] = {}
            if target_user_id not in wins_data[guild_id]:
                wins_data[guild_id][target_user_id] = {"total": 0, "dates": {}}

            # CWV - Update total wins and wins for the current date
            wins_data[guild_id][target_user_id]["total"] += wins
            if current_date in wins_data[guild_id][target_user_id]["dates"]:
                wins_data[guild_id][target_user_id]["dates"][current_date] += wins
            else:
                wins_data[guild_id][target_user_id]["dates"][current_date] = wins

            # CWV - Save updated data to files
            try:
                self.save_json(wins_file, wins_data)
            except Exception as e:
                await interaction.response.send_message(f"Error saving data: {str(e)}", ephemeral=True)
                print(f"Error saving JSON data: {e}")
                return

            # CWV - Prepare the embed message
            embed = discord.Embed(
                title=f"Wins added to {user.name} in {interaction.guild.name}",
                description=(f"Added **{wins}** win(s) to {user.mention}.\n"
                             f"Their new total wins are **{wins_data[guild_id][target_user_id]['total']}**.\n"
                             f"Their total wins today: **{wins_data[guild_id][target_user_id]['dates'][current_date]}**."),
                color=discord.Color.green()
            )

            # CWV - Set the author with the mod's avatar and username
            embed.set_author(name=interaction.user.name, icon_url=interaction.user.avatar.url if interaction.user.avatar else None)

            # CWV - Footer
            embed.set_footer(text="~ Made with ❤️ by CWV")

            # CWV - Respond to the mod
            await interaction.response.send_message(embed=embed)

            # CWV - Log command usage
            await self.log_command_usage(
                interaction.user,
                user,
                interaction.guild,
                wins,
                wins_data[guild_id][target_user_id]["total"],
                wins_data[guild_id][target_user_id]["dates"][current_date]
            )

        except Exception as e:
            error_message = f"An unexpected error occurred: {str(e)}"
            await interaction.response.send_message(error_message, ephemeral=True)
            print(f"Unexpected error in addwin command: {e}")

    @commands.Cog.listener()
    async def on_ready(self):
        print("AddWin cog is ready.")

async def setup(bot):
    await bot.add_cog(AddWin(bot))
