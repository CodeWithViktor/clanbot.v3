import discord
from discord.ext import commands
from discord.ui import Button, View
import json
import math
from datetime import datetime, timedelta

class DynamicLeaderboard(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.Cog.listener()
    async def on_message(self, message):
        # CWV - Check if the bot is mentioned
        if self.bot.user.mentioned_in(message) and not message.author.bot:
            content = message.content.split()
            if len(content) >= 2 and content[1].endswith('d'):
                try:
                    days = int(content[1][:-1])
                    if days < 0 or days > 60:
                        await message.channel.send("Please provide a number of days between 0 and 60.")
                        return

                    # CWV - Call the leaderboard display function with the 'days' range
                    await self.show_leaderboard(message, days)

                except ValueError:
                    await message.channel.send("Invalid format. Use `@economy Xd`, where X is a number of days (0-60).")

    async def show_leaderboard(self, message, days):
        # CWV - Load scores and wins data
        with open('json/scores.json', 'r') as f:
            scores = json.load(f)
        with open('json/wins.json', 'r') as f:
            wins = json.load(f)

        server_id = str(message.guild.id)
        if server_id not in scores:
            await message.channel.send('No data available for this server.')
            return

        server_scores = scores[server_id]
        server_wins = wins.get(server_id, {})

        # CWV - Filter data by date range (past X days)
        start_date = (datetime.utcnow() - timedelta(days=days)).date()

        all_points = {}
        all_wins = {}

        for user_id, user_data in server_scores.items():
            total_points = sum(points for date_str, points in user_data['dates'].items() if datetime.strptime(date_str, '%Y-%m-%d').date() >= start_date)
            all_points[user_id] = total_points

        for user_id, user_data in server_wins.items():
            total_wins = sum(wins for date_str, wins in user_data['dates'].items() if datetime.strptime(date_str, '%Y-%m-%d').date() >= start_date)
            all_wins[user_id] = total_wins

        sorted_points = sorted(all_points.items(), key=lambda x: x[1], reverse=True)
        sorted_wins = sorted(all_wins.items(), key=lambda x: x[1], reverse=True)

        await self.send_leaderboard_embed(message, sorted_points, sorted_wins, days)

    async def send_leaderboard_embed(self, message, sorted_points, sorted_wins, days):
        leaderboard_type = "points"
        page = 1
        max_pages_points = math.ceil(len(sorted_points) / 10)
        max_pages_wins = math.ceil(len(sorted_wins) / 10)

        class LeaderboardView(View):
            def __init__(self, bot_message, leaderboard_type, page):
                super().__init__(timeout=180)
                self.bot_message = bot_message
                self.leaderboard_type = leaderboard_type
                self.page = page
                self.update_buttons()

            def update_buttons(self):
                max_pages = max_pages_points if self.leaderboard_type == "points" else max_pages_wins
                self.previous_page.disabled = self.page == 1
                self.next_page.disabled = self.page == max_pages
                self.wins_leaderboard.label = "Wins Leaderboard" if self.leaderboard_type == "points" else "Points Leaderboard"

            async def update_message(self):
                if self.leaderboard_type == "points":
                    data = sorted_points
                    description = '\n'.join(
                        f"{(self.page-1)*10 + i + 1}. <@{user_id}> - {score} points"
                        for i, (user_id, score) in enumerate(data[(self.page-1)*10:self.page*10])
                    )
                    title = f"{message.guild.name} Points Leaderboard (Last {days} days)"
                else:
                    data = sorted_wins
                    description = '\n'.join(
                        f"{(self.page-1)*10 + i + 1}. <@{user_id}> - {wins} wins"
                        for i, (user_id, wins) in enumerate(data[(self.page-1)*10:self.page*10])
                    )
                    title = f"{message.guild.name} Wins Leaderboard (Last {days} days)"

                embed = discord.Embed(title=title, description=description, color=discord.Color.gold())

                # CWV - Check if the guild has an icon before setting the thumbnail
                if message.guild.icon:
                    embed.set_thumbnail(url=message.guild.icon.url)

                try:
                    await self.bot_message.edit(embed=embed, view=self)
                except discord.NotFound:
                    pass

            @discord.ui.button(label="Previous Page", style=discord.ButtonStyle.secondary, disabled=True)
            async def previous_page(self, interaction: discord.Interaction, button: Button):
                if self.page > 1:
                    self.page -= 1
                    self.update_buttons()
                    await self.update_message()
                    await interaction.response.defer()

            @discord.ui.button(label="Wins Leaderboard", style=discord.ButtonStyle.primary)
            async def wins_leaderboard(self, interaction: discord.Interaction, button: Button):
                if self.leaderboard_type == "points":
                    self.leaderboard_type = "wins"
                else:
                    self.leaderboard_type = "points"
                self.page = 1
                self.update_buttons()
                await self.update_message()
                await interaction.response.defer()

            @discord.ui.button(label="Next Page", style=discord.ButtonStyle.secondary, disabled=True)
            async def next_page(self, interaction: discord.Interaction, button: Button):
                max_pages = max_pages_points if self.leaderboard_type == "points" else max_pages_wins
                if self.page < max_pages:
                    self.page += 1
                    self.update_buttons()
                    await self.update_message()
                    await interaction.response.defer()

        embed = discord.Embed(title="Fetching Leaderboard...", description="Please wait...", color=discord.Color.gold())
        bot_message = await message.channel.send(embed=embed)

        view = LeaderboardView(bot_message, leaderboard_type, page)
        await view.update_message()

async def setup(bot):
    await bot.add_cog(DynamicLeaderboard(bot))
