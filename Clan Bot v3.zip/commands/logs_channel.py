import discord
from discord import app_commands
from discord.ext import commands
import json

class LogsChannel(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    def load_json(self, filepath, default):
        try:
            with open(filepath, 'r') as f:
                return json.load(f)
        except FileNotFoundError:
            return default

    def save_json(self, filepath, data):
        with open(filepath, 'w') as f:
            json.dump(data, f, indent=4)

    def is_mod_or_admin(self, user, guild):
        """ Check if the user has admin or mod role permissions. """
        mod_role_file = './json/mod_roles.json'
        mod_role_data = self.load_json(mod_role_file, {})
        mod_role_id = mod_role_data.get(str(guild.id), {}).get("role")

        return (
            user.guild_permissions.administrator or
            (mod_role_id and discord.utils.get(user.roles, id=int(mod_role_id)))
        )

    @app_commands.command(name="logs_channel", description="Set the logging channel for the server.")
    @app_commands.describe(channel="The channel to log all bot command usage.")
    async def logs_channel(self, interaction: discord.Interaction, channel: discord.TextChannel):
        guild_id = str(interaction.guild.id)

        # CWV - Check if the user is admin or has mod role
        if not self.is_mod_or_admin(interaction.user, interaction.guild):
            await interaction.response.send_message(embed=discord.Embed(
                title="Permission Denied",
                description="You do not have the required permissions to use this command.",
                color=discord.Color.red()
            ), ephemeral=True)
            return

        # CWV - Save the logging channel for this server
        log_channel_file = './json/logging_channels.json'
        log_channel_data = self.load_json(log_channel_file, {})

        log_channel_data[guild_id] = {"channel_id": channel.id}
        self.save_json(log_channel_file, log_channel_data)

        await interaction.response.send_message(embed=discord.Embed(
            title="Logging Channel Set",
            description=f"Logging channel has been set to {channel.mention}.",
            color=discord.Color.green()
        ))

    # CWV - Function to get the log channel
    def get_logging_channel(self, guild):
        log_channel_file = './json/logging_channels.json'
        log_channel_data = self.load_json(log_channel_file, {})
        guild_id = str(guild.id)

        channel_id = log_channel_data.get(guild_id, {}).get("channel_id")
        if channel_id:
            return guild.get_channel(int(channel_id))
        return None

async def setup(bot):
    await bot.add_cog(LogsChannel(bot))
