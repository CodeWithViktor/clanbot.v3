import discord
from discord import app_commands
from discord.ext import commands
from discord.ui import View, Button
import json
from datetime import datetime
import matplotlib.pyplot as plt
from matplotlib.dates import DateFormatter
from io import BytesIO

class Profile(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    def load_json(self, filepath, default):
        try:
            with open(filepath, 'r') as f:
                return json.load(f)
        except FileNotFoundError:
            return default

    def get_month_key(self):
        return datetime.utcnow().strftime("%Y-%m")

    def get_day_key(self):
        return datetime.utcnow().strftime("%Y-%m-%d")

    @app_commands.command(name="profile", description="Display the player's profile")
    @app_commands.describe(player="The player whose profile you want to view")
    async def profile(self, interaction: discord.Interaction, player: discord.User = None):
        player = player or interaction.user
        user_id = str(player.id)
        guild_id = str(interaction.guild.id)

        scores_file = './json/scores.json'
        wins_file = './json/wins.json'

        scores_data = self.load_json(scores_file, {})
        wins_data = self.load_json(wins_file, {})

        total_score = 0
        today_score = 0
        month_score = 0
        total_wins = 0
        today_wins = 0
        month_wins = 0

        current_date = self.get_day_key()
        current_month = self.get_month_key()

        if guild_id in scores_data and user_id in scores_data[guild_id]:
            user_scores = scores_data[guild_id][user_id]
            total_score = user_scores.get('total', 0)
            today_score = user_scores.get('dates', {}).get(current_date, 0)
            month_score = sum(value for date, value in user_scores.get('dates', {}).items() if date.startswith(current_month))

        if guild_id in wins_data and user_id in wins_data[guild_id]:
            user_wins = wins_data[guild_id][user_id]
            total_wins = user_wins.get('total', 0)
            today_wins = user_wins.get('dates', {}).get(current_date, 0)
            month_wins = sum(value for date, value in user_wins.get('dates', {}).items() if date.startswith(current_month))

        embed = discord.Embed(
            title=f"Player Profile",
            description=f"Here are the statistics for {player.mention}",
            color=discord.Color.blue()
        )
        embed.set_author(name=player.name, icon_url=player.avatar.url)

        embed.add_field(
            name="Score Profile",
            value=(
                f"- **Total Score**: {total_score}\n"
                f"- **Today's Score**: {today_score}\n"
                f"- **This Month's Score**: {month_score}"
            ),
            inline=True
        )

        embed.add_field(
            name="Wins Profile",
            value=(
                f"- **Total Battle Wins**: {total_wins}\n"
                f"- **Today's Battle Wins**: {today_wins}\n"
                f"- **This Month's Battle Wins**: {month_wins}"
            ),
            inline=True
        )

        embed.set_footer(text="Made with ❤️ by CWV")

        # CWV - Create a view with buttons for graphs
        view = View()

        # CWV - Button to display score graph
        async def score_graph_callback(interaction: discord.Interaction):
            user_scores = scores_data.get(guild_id, {}).get(user_id, {})
            dates = list(user_scores.get('dates', {}).keys())
            points = [user_scores['dates'][date] for date in dates]

            if not dates or not points:
                await interaction.response.send_message("No data available for the points graph.", ephemeral=True)
                return

            dates = sorted([datetime.strptime(date, '%Y-%m-%d') for date in dates])
            plt.figure(figsize=(10, 6))
            plt.plot(dates, points, marker='o', linestyle='-', linewidth=2.5)
            plt.xlabel('Date')
            plt.ylabel('Points')
            plt.title(f"{player.display_name}'s Points over Time")
            plt.xticks(rotation=45, ha='right')

            date_format = DateFormatter('%d-%b')
            plt.gca().xaxis.set_major_formatter(date_format)

            plt.tight_layout()
            plt.grid(True)
            buf = BytesIO()
            plt.savefig(buf, format='png')
            buf.seek(0)
            plt.close()

            file = discord.File(buf, filename='user_graph.png')
            embed.set_image(url="attachment://user_graph.png")
            await interaction.response.edit_message(embed=embed, attachments=[file])

        score_graph_button = Button(label="Score Graph", emoji="🪙", style=discord.ButtonStyle.blurple)
        score_graph_button.callback = score_graph_callback
        view.add_item(score_graph_button)

        # CWV - Button to display wins graph
        async def wins_graph_callback(interaction: discord.Interaction):
            user_wins = wins_data.get(guild_id, {}).get(user_id, {})
            dates = list(user_wins.get('dates', {}).keys())
            points = [user_wins['dates'][date] for date in dates]

            if not dates or not points:
                await interaction.response.send_message("No data available for the wins graph.", ephemeral=True)
                return

            dates = sorted([datetime.strptime(date, '%Y-%m-%d') for date in dates])
            plt.figure(figsize=(10, 6))
            plt.plot(dates, points, marker='o', linestyle='-', linewidth=2.5)
            plt.xlabel('Date')
            plt.ylabel('Wins')
            plt.title(f"{player.display_name}'s Wins over Time")
            plt.xticks(rotation=45, ha='right')

            date_format = DateFormatter('%d-%b')
            plt.gca().xaxis.set_major_formatter(date_format)

            plt.tight_layout()
            plt.grid(True)
            buf = BytesIO()
            plt.savefig(buf, format='png')
            buf.seek(0)
            plt.close()

            file = discord.File(buf, filename='user_wins_graph.png')
            embed.set_image(url="attachment://user_wins_graph.png")
            await interaction.response.edit_message(embed=embed, attachments=[file])

        wins_graph_button = Button(label="Wins Graph", emoji="🏆", style=discord.ButtonStyle.blurple)
        wins_graph_button.callback = wins_graph_callback
        view.add_item(wins_graph_button)

        # CWV - Send the profile message with buttons
        await interaction.response.send_message(embed=embed, view=view)

    @commands.Cog.listener()
    async def on_ready(self):
        print("Profile cog is ready.")

async def setup(bot):
    await bot.add_cog(Profile(bot))
