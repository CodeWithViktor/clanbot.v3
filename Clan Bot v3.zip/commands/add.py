import discord
from discord import app_commands
from discord.ext import commands
import json
from datetime import datetime
import os

class Add(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    def load_json(self, filepath, default):
        """Load JSON data from a file, return default if file does not exist."""
        if not os.path.exists(filepath):
            return default
        with open(filepath, 'r') as f:
            return json.load(f)

    def save_json(self, filepath, data):
        """Save JSON data to a file."""
        with open(filepath, 'w') as f:
            json.dump(data, f, indent=4)

    async def log_command_usage(self, user, guild, command_name, points_added, adjusted_points, total_points, total_wins):
        """Log command usage to the designated logging channel."""
        log_channel_file = './json/logging_channels.json'
        log_channel_data = self.load_json(log_channel_file, {})

        channel_id = log_channel_data.get(str(guild.id), {}).get("channel_id")
        if channel_id:
            log_channel = self.bot.get_channel(int(channel_id))
            if log_channel:
                try:
                    embed = discord.Embed(
                        title="Command Usage Log",
                        description=(f"**Command:** {command_name}\n"
                                     f"**User:** {user}\n"
                                     f"**Points Added:** {points_added}\n"
                                     f"**Adjusted Points (after multiplier):** {adjusted_points}\n"
                                     f"**Total Points:** {total_points}\n"
                                     f"**Total Wins:** {total_wins}\n"
                                     f"**Channel:** {user.dm_channel if user.dm_channel else 'DM'}\n"
                                     f"**Time:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"),
                        color=discord.Color.blue()
                    )
                    await log_channel.send(embed=embed)
                except Exception as e:
                    print(f"Failed to send log message: {e}")

    @app_commands.command(name="add", description="Add your points (max 750) with two decimal precision")
    @app_commands.describe(points="The number of points to add (max 750)")
    async def add(self, interaction: discord.Interaction, points: float):
        # CWV - Defer the response immediately
        await interaction.response.defer(ephemeral=False)

        # CWV - Validate points
        if points <= 0 or points > 750 or len(str(points).split(".")[1]) > 2:
            await interaction.followup.send("Please enter a positive number with up to two decimal places, and the maximum is 750.", ephemeral=True)
            return

        user_id = str(interaction.user.id)
        guild_id = str(interaction.guild.id)
        current_date = str(datetime.utcnow().date())

        # CWV - File paths
        scores_file = './json/scores.json'
        wins_file = './json/wins.json'
        multiplier_file = './json/multiplier.json'

        # CWV - Load existing data
        scores_data = self.load_json(scores_file, {})
        wins_data = self.load_json(wins_file, {})
        multiplier_data = self.load_json(multiplier_file, {})

        # CWV - Determine the multiplier for the server (if set)
        multiplier = multiplier_data.get(guild_id, {}).get('default', 1)  # CWV - Default multiplier is 1
        adjusted_points = points * multiplier  # CWV - Apply multiplier to the points

        # CWV - Update scores_data
        if guild_id not in scores_data:
            scores_data[guild_id] = {}
        if user_id not in scores_data[guild_id]:
            scores_data[guild_id][user_id] = {"total": 0, "dates": {}}

        # CWV - Update total points and points for the current date
        scores_data[guild_id][user_id]["total"] += adjusted_points
        if current_date in scores_data[guild_id][user_id]["dates"]:
            scores_data[guild_id][user_id]["dates"][current_date] += adjusted_points
        else:
            scores_data[guild_id][user_id]["dates"][current_date] = adjusted_points

        # CWV - Update wins_data
        if guild_id not in wins_data:
            wins_data[guild_id] = {}
        if user_id not in wins_data[guild_id]:
            wins_data[guild_id][user_id] = {"total": 0, "dates": {}}

        # CWV - Increment total wins and wins for the current date
        wins_data[guild_id][user_id]["total"] += 1
        if current_date in wins_data[guild_id][user_id]["dates"]:
            wins_data[guild_id][user_id]["dates"][current_date] += 1
        else:
            wins_data[guild_id][user_id]["dates"][current_date] = 1

        # CWV - Save updated data to files
        self.save_json(scores_file, scores_data)
        self.save_json(wins_file, wins_data)

        # CWV - Prepare the embed message
        embed = discord.Embed(
            title=f"Points added in {interaction.guild.name}",
            color=discord.Color.green()
        )

        # CWV - Check if the multiplier was applied and customize the message
        if multiplier > 1:
            embed.description = (f"Added **{points}** points (multiplied by **{multiplier}**) to your total, resulting in **{adjusted_points}** points.\n"
                                 f"Your new total points are **{scores_data[guild_id][user_id]['total']}**.\n"
                                 f"Your total battle wins are **{wins_data[guild_id][user_id]['total']}**.")
        else:
            embed.description = (f"Added **{points}** points to your total.\n"
                                 f"Your new total points are **{scores_data[guild_id][user_id]['total']}**.\n"
                                 f"Your total battle wins are **{wins_data[guild_id][user_id]['total']}**.")

        # CWV - Set the author with the user's avatar and username
        avatar_url = interaction.user.avatar.url if interaction.user.avatar else None
        embed.set_author(name=interaction.user.name, icon_url=avatar_url)

        # CWV - Footer
        embed.set_footer(text="~ Made with ❤️ by CWV")

        # CWV - Respond to the user
        await interaction.followup.send(embed=embed)

        # CWV - Log the command usage with detailed information
        await self.log_command_usage(
            interaction.user, 
            interaction.guild, 
            "add", 
            points, 
            adjusted_points, 
            scores_data[guild_id][user_id]['total'], 
            wins_data[guild_id][user_id]['total']
        )

    @commands.Cog.listener()
    async def on_ready(self):
        print("Add cog is ready.")

async def setup(bot):
    await bot.add_cog(Add(bot))
