import discord
from discord import app_commands
from discord.ext import commands
import json
from datetime import datetime  # CWV - Import datetime for timestamping logs

class RemoveModRole(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    def load_json(self, filepath, default):
        try:
            with open(filepath, 'r') as f:
                return json.load(f)
        except FileNotFoundError:
            return default

    def save_json(self, filepath, data):
        with open(filepath, 'w') as f:
            json.dump(data, f, indent=4)

    def log_event(self, guild_id, user_id, action, details):
        """Log events to a file."""
        log_file = './json/event_logs.json'
        log_data = self.load_json(log_file, [])

        log_entry = {
            "timestamp": datetime.utcnow().isoformat(),
            "guild_id": guild_id,
            "user_id": user_id,
            "action": action,
            "details": details
        }
        
        log_data.append(log_entry)
        self.save_json(log_file, log_data)

    @app_commands.command(name="remove-modrole", description="Remove a role from the mod roles list")
    @app_commands.describe(mod_role="The role to remove from the mod roles list")
    async def remove_modrole(self, interaction: discord.Interaction, mod_role: discord.Role):
        # CWV - Check if the user has administrator permissions
        if not interaction.user.guild_permissions.administrator:
            await interaction.response.send_message(embed=discord.Embed(
                title="Permission Denied",
                description="You do not have the required permissions to use this command.",
                color=discord.Color.red()
            ), ephemeral=True)
            return

        mod_file = './json/mod.json'
        mod_data = self.load_json(mod_file, {})

        guild_id = str(interaction.guild.id)
        if guild_id not in mod_data or mod_role.id not in mod_data[guild_id].get("roles", []):
            await interaction.response.send_message(embed=discord.Embed(
                title="Role Not Found",
                description=f"The role {mod_role.mention} is not set as a mod role.",
                color=discord.Color.red()
            ), ephemeral=True)
            return

        # CWV - Remove the role from the mod roles list
        mod_data[guild_id]["roles"].remove(mod_role.id)
        if not mod_data[guild_id]["roles"]:
            del mod_data[guild_id]

        # CWV - Save updated mod role data
        self.save_json(mod_file, mod_data)

        # CWV - Log the event
        log_details = {
            "action": "remove_modrole",
            "status": "success",
            "role": mod_role.id,
            "role_name": mod_role.name
        }
        self.log_event(guild_id, interaction.user.id, "remove_modrole", log_details)

        # CWV - Send success message
        await interaction.response.send_message(embed=discord.Embed(
            title="Mod Role Removed",
            description=f"The role {mod_role.mention} has been removed from the mod roles list.",
            color=discord.Color.green()
        ))

async def setup(bot):
    await bot.add_cog(RemoveModRole(bot))
