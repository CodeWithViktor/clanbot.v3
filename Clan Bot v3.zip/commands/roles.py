import discord
from discord import app_commands
from discord.ext import commands
import json

class RoleInfo(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    def load_json(self, filepath, default):
        """Load JSON data from a file, return default if file does not exist."""
        try:
            with open(filepath, 'r') as f:
                return json.load(f)
        except FileNotFoundError:
            return default

    @app_commands.command(name="roles", description="List all available reward roles")
    async def roles(self, interaction: discord.Interaction):
        # CWV - Load reward roles data from the JSON file
        reward_file = './json/reward_roles.json'
        reward_data = self.load_json(reward_file, {})

        guild_id = str(interaction.guild_id)

        if guild_id not in reward_data or len(reward_data[guild_id]) == 0:
            embed = discord.Embed(
                title="🎖️ Reward Roles",
                description="No reward roles have been set for this server. 🎯",
                color=discord.Color.orange()
            )
            await interaction.response.send_message(embed=embed)
            return

        # CWV - Separate roles based on points and wins
        points_roles = []
        wins_roles = []

        for role_id, settings in reward_data[guild_id].items():
            role = interaction.guild.get_role(int(role_id))
            if role:
                if settings["type"].lower() == "points":
                    points_roles.append((role, settings["amount"]))
                elif settings["type"].lower() == "wins":
                    wins_roles.append((role, settings["amount"]))

        # CWV - Sort roles by amount (higher to lower)
        points_roles.sort(key=lambda x: x[1], reverse=True)
        wins_roles.sort(key=lambda x: x[1], reverse=True)

        # CWV - Create the embed
        embed = discord.Embed(
            title="🎖️ Available Reward Roles",
            description="Check out the reward roles you can earn by achieving milestones!",
            color=discord.Color.blue()
        )
        
        # CWV - Add fields for points roles
        if points_roles:
            points_field = "\n".join([f"🏅 {role.mention} - {amount} points" for role, amount in points_roles])
            embed.add_field(name="Points Roles", value=points_field, inline=False)
        else:
            embed.add_field(name="Points Roles", value="No roles available for points. 🚫", inline=False)
        
        # CWV - Add fields for wins roles
        if wins_roles:
            wins_field = "\n".join([f"🥇 {role.mention} - {amount} wins" for role, amount in wins_roles])
            embed.add_field(name="Wins Roles", value=wins_field, inline=False)
        else:
            embed.add_field(name="Wins Roles", value="No roles available for wins. 🚫", inline=False)

        # CWV - Set footer and send the message
        embed.set_footer(text="Earn these roles by reaching the required points or wins! 🌟")
        await interaction.response.send_message(embed=embed)

async def setup(bot):
    await bot.add_cog(RoleInfo(bot))
