import discord
from discord.ext import commands, tasks
import json
import os

class RoleAssignment(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.check_roles.start()
        self.assigned_roles_file = './json/assigned_roles.json'
        self.assigned_roles = self.load_json(self.assigned_roles_file, {})
        self.previous_scores = {}
        self.previous_wins = {}

    def load_json(self, filename, default=None):
        """Load data from a JSON file."""
        try:
            if os.path.exists(filename):
                with open(filename, 'r') as f:
                    return json.load(f)
            return default
        except Exception as e:
            print(f"Error loading JSON from {filename}: {e}")
            return default

    def save_json(self, filename, data):
        """Save data to a JSON file."""
        try:
            os.makedirs(os.path.dirname(filename), exist_ok=True)
            with open(filename, 'w') as f:
                json.dump(data, f, indent=4)
        except Exception as e:
            print(f"Error saving JSON to {filename}: {e}")

    @tasks.loop(seconds=5)
    async def check_roles(self):
        # CWV - Rest of your check_roles code remains the same
        reward_file = './json/reward_roles.json'
        reward_data = self.load_json(reward_file, {})
        scores_file = './json/scores.json'
        wins_file = './json/wins.json'
        
        # CWV - Load current scores and wins
        current_scores = self.load_json(scores_file, {})
        current_wins = self.load_json(wins_file, {})
        
        # CWV - ... rest of your existing check_roles code ...

        for guild_id, roles in reward_data.items():
            guild = self.bot.get_guild(int(guild_id))
            if guild is None:
                continue

            guild_scores = current_scores.get(str(guild_id), {})
            guild_wins = current_wins.get(str(guild_id), {})

            # CWV - Initialize previous scores/wins for this guild if not exists
            if str(guild_id) not in self.previous_scores:
                self.previous_scores[str(guild_id)] = {}
            if str(guild_id) not in self.previous_wins:
                self.previous_wins[str(guild_id)] = {}

            for role_id, settings in roles.items():
                role = guild.get_role(int(role_id))
                if role is None:
                    continue

                channel = guild.get_channel(settings["channel_id"])
                if channel is None:
                    continue

                for user_id, data in guild_scores.items():
                    try:
                        user = await guild.fetch_member(int(user_id))
                    except discord.NotFound:
                        continue

                    current_points = data.get("total", 0)
                    
                    # CWV - Get previous values
                    prev_points = self.previous_scores[str(guild_id)].get(user_id, 0)
                    prev_wins = self.previous_wins[str(guild_id)].get(user_id, 0)

                    milestone_reached = False

                    if settings["type"].lower() == "points":
                        # CWV - Check if user just crossed the threshold
                        if current_points >= settings["amount"] and prev_points < settings["amount"]:
                            milestone_reached = True
                    elif settings["type"].lower() == "wins":
                        # CWV - Check if user just crossed the threshold
                        if current_wins >= settings["amount"] and prev_wins < settings["amount"]:
                            milestone_reached = True

                    # CWV - Update previous values

                    if milestone_reached and not self.is_role_assigned(guild_id, user_id, role_id):
                        if role not in user.roles:
                            try:
                                await user.add_roles(role)
                                embed = discord.Embed(
                                    title="🏅 Congratulations! 🏅",
                                    description=(
                                        f"🎉 {user.mention}, you've reached a **milestone** by earning "
                                        f"{'**' + str(current_points) + '** points' if settings['type'].lower() == 'points' else '**' + str(current_wins) + '** wins'}!\n\n"
                                        f"You've been awarded the **{role.name}** role! Keep it up! 💪"
                                    ),
                                    color=discord.Color.gold()
                                )
                                embed.set_thumbnail(url=user.avatar.url)
                                embed.set_footer(text=f"Milestone reached for {settings['type'].capitalize()} | Keep pushing for the next one!")
                                
                                await channel.send(embed=embed)
                                self.mark_role_as_assigned(guild_id, user_id, role_id)
                                print(f"Role {role.name} assigned to {user.name} for {settings['type']} milestone.")
                            except discord.Forbidden:
                                print(f"Permission error: Could not assign role {role_id} to user {user_id}.")
                            except Exception as e:
                                print(f"Error assigning role {role_id} to user {user_id}: {e}")

    def is_role_assigned(self, guild_id, user_id, role_id):
        """Check if a role has been assigned to a user."""
        return self.assigned_roles.get(str(guild_id), {}).get(str(user_id), {}).get(str(role_id), False)

    def mark_role_as_assigned(self, guild_id, user_id, role_id):
        """Mark a role as assigned for a user."""
        if str(guild_id) not in self.assigned_roles:
            self.assigned_roles[str(guild_id)] = {}
        if str(user_id) not in self.assigned_roles[str(guild_id)]:
            self.assigned_roles[str(guild_id)][str(user_id)] = {}
        self.assigned_roles[str(guild_id)][str(user_id)][str(role_id)] = True
        self.save_json(self.assigned_roles_file, self.assigned_roles)

    @check_roles.before_loop
    async def before_check_roles(self):
        await self.bot.wait_until_ready()

async def setup(bot):
    await bot.add_cog(RoleAssignment(bot))
