import discord
from discord import app_commands
from discord.ext import commands
import json
from datetime import datetime  # CWV - Import datetime for timestamping logs

class RoleManagement(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    def load_json(self, filepath, default):
        """Load JSON data from a file, return default if file does not exist."""
        try:
            with open(filepath, 'r') as f:
                return json.load(f)
        except FileNotFoundError:
            return default

    def save_json(self, filepath, data):
        """Save JSON data to a file."""
        with open(filepath, 'w') as f:
            json.dump(data, f, indent=4)

    def is_mod(self, guild_id, user_id):
        """Check if a user is a mod based on the mod files."""
        mod_users_file = './json/moduser.json'
        mod_roles_file = './json/mod.json'

        # CWV - Load mod data
        mod_users = self.load_json(mod_users_file, {}).get(guild_id, {}).get("users", [])
        mod_roles = self.load_json(mod_roles_file, {}).get(guild_id, {}).get("roles", [])

        # CWV - Check if the user is in the mod list for the guild or has a mod role
        member = self.bot.get_guild(int(guild_id)).get_member(int(user_id))
        
        # CWV - If the user is in the mod_users list or has a mod role, return True
        return str(user_id) in mod_users or (member and any(role.id in mod_roles for role in member.roles))

    def log_event(self, guild_id, user_id, action, details):
        """Log events to a file."""
        log_file = './json/event_logs.json'
        log_data = self.load_json(log_file, [])

        log_entry = {
            "timestamp": datetime.utcnow().isoformat(),
            "guild_id": guild_id,
            "user_id": user_id,
            "action": action,
            "details": details
        }
        
        log_data.append(log_entry)
        self.save_json(log_file, log_data)

    @app_commands.command(name="remove_rewardrole", description="Remove a reward role")
    async def remove_rewardrole(self, interaction: discord.Interaction, role: discord.Role):
        guild_id = str(interaction.guild.id)
        user_id = str(interaction.user.id)

        # CWV - Check if the user has mod permissions
        if not self.is_mod(guild_id, user_id):
            await interaction.response.send_message(
                embed=discord.Embed(
                    title="❌ Permission Denied",
                    description="You do not have the necessary permissions to use this command.",
                    color=discord.Color.red()
                ), ephemeral=True
            )
            return

        # CWV - Load the reward roles data from the JSON file
        reward_file = './json/reward_roles.json'
        reward_data = self.load_json(reward_file, {})

        role_id = str(role.id)

        # CWV - Check if the guild and role are in the reward_roles.json file
        if guild_id in reward_data and role_id in reward_data[guild_id]:
            # CWV - Remove the role from the JSON data
            del reward_data[guild_id][role_id]

            # CWV - Save the updated data back to the JSON file
            self.save_json(reward_file, reward_data)

            # CWV - Log the event
            log_details = {
                "action": "remove_rewardrole",
                "status": "success",
                "role_id": role_id,
                "role_name": str(role)
            }
            self.log_event(guild_id, user_id, "remove_rewardrole", log_details)

            # CWV - Send a success message
            embed = discord.Embed(
                title="✅ Reward Role Removed",
                description=f"The reward role {role.mention} has been successfully removed from the rewards system.",
                color=discord.Color.green()
            )
            await interaction.response.send_message(embed=embed)

        else:
            # CWV - If the role wasn't found in the rewards data
            embed = discord.Embed(
                title="❌ Role Not Found",
                description=f"The role {role.mention} is not set as a reward role.",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed)

    @remove_rewardrole.error
    async def remove_rewardrole_error(self, interaction: discord.Interaction, error):
        if isinstance(error, app_commands.MissingPermissions):
            await interaction.response.send_message(
                embed=discord.Embed(
                    title="❌ Permission Denied",
                    description="You do not have the necessary permissions to use this command.",
                    color=discord.Color.red()
                ), ephemeral=True
            )
        else:
            await interaction.response.send_message(
                embed=discord.Embed(
                    title="⚠️ Error",
                    description=f"An unexpected error occurred: {error}",
                    color=discord.Color.red()
                ), ephemeral=True
            )

async def setup(bot):
    await bot.add_cog(RoleManagement(bot))
