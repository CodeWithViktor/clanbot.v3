import discord
from discord import app_commands
from discord.ext import commands
import time
import datetime
import psutil
import platform
import sys

class About(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.start_time = time.time()

    @app_commands.command(name="about", description="Shows detailed information about the bot")
    async def about(self, interaction: discord.Interaction):
        if not await self.check_bot_channel(interaction):
            return
        # CWV - Calculate uptime
        current_time = time.time()
        difference = int(round(current_time - self.start_time))
        uptime = str(datetime.timedelta(seconds=difference))

        # CWV - Get server and user count
        server_count = len(self.bot.guilds)
        user_count = sum(guild.member_count for guild in self.bot.guilds)

        # CWV - Get system information
        cpu_usage = psutil.cpu_percent()
        memory_usage = psutil.virtual_memory().percent
        disk_usage = psutil.disk_usage('/').percent

        # CWV - Create embed
        embed = discord.Embed(
            title="About TT.io Clan Bot",
            description="A sophisticated bot designed for managing Territorial.io clan activities with precision and efficiency.",
            color=discord.Color.blue()
        )

        # CWV - Add bot avatar as thumbnail if available
        if self.bot.user.avatar:
            embed.set_thumbnail(url=self.bot.user.avatar.url)

        # CWV - Bot Information
        embed.add_field(name="🤖 Bot Information", value=(
            f"**Name:** {self.bot.user.name}\n"
            f"**ID:** {self.bot.user.id}\n"
            f"**Version:** 1.2.0\n"
            f"**Uptime:** {uptime}\n"
            f"**Servers:** {server_count}\n"
            f"**Users:** {user_count:,}"
        ), inline=False)

        # CWV - System Information
        embed.add_field(name="💻 System Information", value=(
            f"**Python Version:** {platform.python_version()}\n"
            f"**Discord.py Version:** {discord.__version__}\n"
            f"**OS:** {platform.system()} {platform.release()}\n"
            f"**CPU Usage:** {cpu_usage}%\n"
            f"**Memory Usage:** {memory_usage}%\n"
            f"**Disk Usage:** {disk_usage}%"
        ), inline=False)

        # CWV - Features
        embed.add_field(name="🌟 Key Features", value=(
            "• Automated role assignment\n"
            "• Point tracking system\n"
            "• Battle win statistics\n"
            "• Customizable multipliers\n"
            "• Leaderboard functionality\n"
            "• Detailed logging and analytics"
        ), inline=False)

        # CWV - Developer Information
        embed.add_field(name="👨‍💻 Developer", value="CWV", inline=True)
        embed.add_field(name="📅 Last Updated", value="2023-06-15", inline=True)

        # CWV - Support and Links
        embed.add_field(name="🔗 Links", value=(
            "[Support Server](https://discord.gg/dyN3kSamTH)\n"
            "[Invite Bot](https://discord.com/oauth2/authorize?client_id=1271425598018945104&permissions=1126452078824448&response_type=code&redirect_uri=https%3A%2F%2Fdiscord.com%2Foauth2%2Fauthorize%3Fclient_id%3D1271425598018945104&integration_type=0&scope=identify+bot)\n"
        ), inline=False)

        embed.set_footer(text="Made with ❤️ by CWV | Empowering Territorial.io clans")

        await interaction.response.send_message(embed=embed)

    @commands.Cog.listener()
    async def on_ready(self):
        print("About cog is ready.")

async def setup(bot):
    await bot.add_cog(About(bot))
