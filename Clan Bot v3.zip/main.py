import discord
from discord.ext import commands
import json
from datetime import datetime
import os 

intents = discord.Intents.default()
intents.message_content = True
intents.typing = True
intents.presences = True
intents.members = True

bot = commands.Bot(command_prefix="/", intents=intents)

import json
import os

# CWV - Add these functions at the top of your file, after the imports
def load_json(filename, default):
    if os.path.exists(filename):
        with open(filename, 'r') as f:
            return json.load(f)
    return default

async def check_bot_channel(interaction: discord.Interaction):
    bot_channels = load_json('./json/bot_channels.json', {})
    guild_id = str(interaction.guild_id)
    channel_id = str(interaction.channel_id)
    
    if guild_id in bot_channels:
        if channel_id not in bot_channels[guild_id]:
            await interaction.response.send_message("This command can only be used in designated bot channels.", ephemeral=True)
            return False
    return True


async def log_command_usage(guild_id, command_name, user, channel):
    """Log command usage to the designated logging channel."""
    log_channel_file = './json/logging_channels.json'
    log_channel_data = {}

    try:
        with open(log_channel_file, 'r') as f:
            log_channel_data = json.load(f)
    except FileNotFoundError:
        log_channel_data = {}

    channel_id = log_channel_data.get(str(guild_id), {}).get("channel_id")
    if channel_id:
        log_channel = bot.get_channel(int(channel_id))
        if log_channel:
            try:
                embed = discord.Embed(
                    title="Command Used",
                    description=f"**Command:** {command_name}\n**User:** {user}\n**Channel:** {channel}\n**Time:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
                    color=discord.Color.blue()
                )
                await log_channel.send(embed=embed)
            except Exception as e:
                print(f"Failed to send log message: {e}")

# CWV - Load commands from the commands folder
async def load_commands():
    """Lazy load only necessary commands when requested."""
    for filename in os.listdir('./commands'):
        if filename.endswith('.py'):
            extension_name = f'commands.{filename[:-3]}'
            try:
                await bot.load_extension(extension_name)
                print(f"Loaded extension {extension_name}")
            except commands.errors.ExtensionAlreadyLoaded:
                print(f'Extension {extension_name} is already loaded, skipping...')
            except Exception as e:
                print(f"Failed to load extension {extension_name}: {e}")

@bot.event
async def on_ready():
    await load_commands()
    await bot.tree.sync()
    print(f'{bot.user} has connected to Discord!\n~ CW Viktor\nhttps://dsc.gg/ttiobots')
    await bot.change_presence(status=discord.Status.online, activity=discord.Game('VT Corp - Territorial.io Development'))


TOKEN = ''
bot.run(TOKEN)